import algosdk from 'algosdk';
import { AlgorandClientTransactionCreator } from '../types/algorand-client-transaction-creator';
import { AlgorandClientTransactionSender } from '../types/algorand-client-transaction-sender';
import { ABIAppCallArgs, BoxIdentifier as LegacyBoxIdentifier, BoxReference as LegacyBoxReference, RawAppCallArgs } from '../types/app';
import { AppCallMethodCall, AppCallParams, AppCreateMethodCall, AppCreateParams, AppDeleteMethodCall, AppDeleteParams, AppUpdateMethodCall, AppUpdateParams, BuiltTransactions, CommonTransactionParams } from '../types/composer';
import { SendParams, SendSingleTransactionResult, SendTransactionFrom, SendTransactionParams, SendTransactionResult, TransactionNote } from '../types/transaction';
import Algodv2 = algosdk.Algodv2;
import Transaction = algosdk.Transaction;
/** @deprecated Bridges between legacy `sendTransaction` behaviour and new `AlgorandClient` behaviour. */
export declare function legacySendTransactionBridge<T extends CommonTransactionParams, TResult extends SendSingleTransactionResult>(algod: Algodv2, from: SendTransactionFrom, sendParams: SendTransactionParams, params: T, txn: ((c: AlgorandClientTransactionCreator) => (params: T) => Promise<Transaction>) | ((c: AlgorandClientTransactionCreator) => (params: T) => Promise<BuiltTransactions>), send: (c: AlgorandClientTransactionSender) => (params: T & SendParams) => Promise<TResult>, suggestedParams?: algosdk.SuggestedParams): Promise<(SendTransactionResult | TResult) & {
    transactions: Transaction[];
}>;
/** @deprecated Bridges between legacy `sendTransaction` behaviour for app transactions and new `AlgorandClient` behaviour. */
export declare function legacySendAppTransactionBridge<T extends AppCreateParams | AppUpdateParams | AppDeleteParams | AppCallParams | AppCreateMethodCall | AppUpdateMethodCall | AppDeleteMethodCall | AppCallMethodCall, TResult extends SendSingleTransactionResult>(algod: Algodv2, from: SendTransactionFrom, appArgs: RawAppCallArgs | ABIAppCallArgs | undefined, sendParams: SendTransactionParams & {
    note?: TransactionNote;
}, params: Omit<T, 'accountReferences' | 'appReferences' | 'assetReferences' | 'boxReferences' | 'args' | 'lease' | 'rekeyTo' | 'note'>, txn: ((c: AlgorandClientTransactionCreator) => (params: T) => Promise<Transaction>) | ((c: AlgorandClientTransactionCreator) => (params: T) => Promise<BuiltTransactions>), send: (c: AlgorandClientTransactionSender) => (params: T & SendParams) => Promise<TResult>, suggestedParams?: algosdk.SuggestedParams): Promise<(SendTransactionResult | TResult) & {
    transactions: Transaction[];
}>;
/**
 * @deprecated
 */
export declare function _getAppArgsForABICall(args: ABIAppCallArgs, from: SendTransactionFrom): Promise<{
    method: algosdk.ABIMethod;
    sender: string;
    signer: algosdk.TransactionSigner;
    boxes: algosdk.BoxReference[] | undefined;
    lease: Uint8Array<ArrayBufferLike> | undefined;
    appForeignApps: number[] | undefined;
    appForeignAssets: number[] | undefined;
    appAccounts: string[] | undefined;
    methodArgs: (string | number | bigint | boolean | algosdk.Address | Uint8Array<ArrayBufferLike> | algosdk.ABIValue[] | algosdk.TransactionWithSigner)[];
    rekeyTo: string | undefined;
}>;
/** @deprecated */
export declare function _getBoxReference(box: LegacyBoxIdentifier | LegacyBoxReference | algosdk.BoxReference): algosdk.BoxReference;
