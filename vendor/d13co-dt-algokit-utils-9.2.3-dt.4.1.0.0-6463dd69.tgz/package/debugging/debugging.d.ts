/**
 * @deprecated Use latest version of `AlgoKit AVM Debugger` VSCode extension instead. It will automatically manage your sourcemaps.
 *
 * This function persists the source maps for the given sources.
 *
 * @returns A promise that resolves when the source maps have been persisted.
 */
export declare function persistSourceMaps(_params: unknown): Promise<void>;
