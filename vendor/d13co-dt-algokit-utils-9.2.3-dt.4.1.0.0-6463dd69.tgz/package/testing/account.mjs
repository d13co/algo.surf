import { Config } from "../config.mjs";
import { AlgorandClient } from "../types/algorand-client.mjs";
import algosdk, { Address } from "algosdk";
//#region src/testing/account.ts
async function getTestAccount({ suppressLog, initialFunds, accountGetter }, algodOrAlgorandClient, kmd) {
	const algorand = algodOrAlgorandClient instanceof AlgorandClient ? algodOrAlgorandClient : AlgorandClient.fromClients({
		algod: algodOrAlgorandClient,
		kmd
	});
	const account = accountGetter ? await accountGetter(algorand) : algosdk.generateAccount();
	Config.getLogger(suppressLog).info(`New test account created with address '${account.addr}' and mnemonic '${algosdk.secretKeyToMnemonic(account.sk)}'.`);
	const dispenser = await algorand.account.dispenserFromEnvironment();
	await algorand.send.payment({
		sender: dispenser,
		receiver: account.addr,
		amount: initialFunds,
		note: "Funding test account",
		suppressLog
	});
	const accountInfo = await algorand.account.getInformation(account.addr);
	Config.getLogger(suppressLog).info("Test account funded; account balance: %d µALGO", accountInfo.balance.microAlgo);
	algorand.setSignerFromAccount(account);
	const address = Address.fromString(account.addr.toString());
	address.addr = account.addr;
	address.sk = account.sk;
	address.signer = algorand.account.getSigner(address);
	return address;
}
//#endregion
export { getTestAccount };

//# sourceMappingURL=account.mjs.map