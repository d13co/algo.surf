//#region src/testing/indexer.ts
/**
* Runs the given indexer call until a 404 error is no longer returned.
* Tried every 200ms up to 100 times.
* Very rudimentary implementation designed for automated testing.
* @example
* ```typescript
* const transaction = await runWhenIndexerCaughtUp(() => indexer.lookupTransactionByID(txnId).do())
* ```
* @param run The code to run
* @returns The result (as a promise), or throws if the indexer didn't catch up in time
*/
async function runWhenIndexerCaughtUp(run) {
	let result = null;
	let ok = false;
	let tries = 0;
	while (!ok) try {
		result = await run();
		ok = true;
	} catch (e) {
		if (e?.status === 404) {
			tries++;
			if (tries > 100) throw e;
			await new Promise((resolve) => setTimeout(resolve, 200));
		} else throw e;
	}
	return result;
}
//#endregion
export { runWhenIndexerCaughtUp };

//# sourceMappingURL=indexer.mjs.map