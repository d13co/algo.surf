const require_dispenser_client = require("./types/dispenser-client.js");
//#region src/dispenser-client.ts
/**
* @deprecated Use `clientManager.getTestNetDispenser` or `clientManager.getTestNetDispenserFromEnvironment` instead
*
* Create a new TestNetDispenserApiClient instance.
* Refer to [docs](https://github.com/algorandfoundation/algokit/blob/main/docs/testnet_api.md) on guidance to obtain an access token.
*
* @param params An object containing parameters for the TestNetDispenserApiClient class.
* Or null if you want the client to load the access token from the environment variable `ALGOKIT_DISPENSER_ACCESS_TOKEN`.
* @example
* const client = algokit.getTestNetDispenserApiClient(
*     {
*       authToken: 'your_auth_token',
*       requestTimeout: 15,
*     }
* )
*
* @returns An instance of the TestNetDispenserApiClient class.
*/
function getTestNetDispenserApiClient(params = null) {
	return new require_dispenser_client.TestNetDispenserApiClient(params === null ? void 0 : params);
}
//#endregion
exports.getTestNetDispenserApiClient = getTestNetDispenserApiClient;

//# sourceMappingURL=dispenser-client.js.map