import algosdk from 'algosdk';
import Algodv2 = algosdk.Algodv2;
/** @deprecated Use `await algorand.client.isLocalNet()` or `await new ClientManager({ algod }).isLocalNet()` instead.
 *
 * Returns true if the algod client is pointing to a LocalNet Algorand network
 */
export declare function isLocalNet(algod: Algodv2): Promise<boolean>;
