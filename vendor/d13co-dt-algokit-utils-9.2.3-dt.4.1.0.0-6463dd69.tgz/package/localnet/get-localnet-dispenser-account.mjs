import { ClientManager } from "../types/client-manager.mjs";
import { AccountManager } from "../types/account-manager.mjs";
//#region src/localnet/get-localnet-dispenser-account.ts
/**
* @deprecated Use `algorand.account.kmd.getLocalNetDispenserAccount()` instead.
*
* Returns an Algorand account with private key loaded for the default LocalNet dispenser account (that can be used to fund other accounts)
*
* @param algod An algod client
* @param kmd A KMD client, if not specified then a default KMD client will be loaded from environment variables
*/
async function getLocalNetDispenserAccount(algod, kmd) {
	return (await new AccountManager(new ClientManager({
		algod,
		kmd
	})).kmd.getLocalNetDispenserAccount()).account;
}
//#endregion
export { getLocalNetDispenserAccount };

//# sourceMappingURL=get-localnet-dispenser-account.mjs.map