const require_client_manager = require("../types/client-manager.js");
//#region src/localnet/is-localnet.ts
/** @deprecated Use `await algorand.client.isLocalNet()` or `await new ClientManager({ algod }).isLocalNet()` instead.
*
* Returns true if the algod client is pointing to a LocalNet Algorand network
*/
async function isLocalNet(algod) {
	return await new require_client_manager.ClientManager({ algod }).isLocalNet();
}
//#endregion
exports.isLocalNet = isLocalNet;

//# sourceMappingURL=is-localnet.js.map