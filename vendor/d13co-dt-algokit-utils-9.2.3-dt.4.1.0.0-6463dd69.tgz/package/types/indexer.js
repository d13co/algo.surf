Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
//#region src/types/indexer.ts
/** Defines the what additional actions occur with the transaction https://dev.algorand.co/reference/rest-api/indexer/#oncompletion */
let ApplicationOnComplete = /* @__PURE__ */ function(ApplicationOnComplete) {
	ApplicationOnComplete["noop"] = "noop";
	ApplicationOnComplete["optin"] = "optin";
	ApplicationOnComplete["closeout"] = "closeout";
	ApplicationOnComplete["clear"] = "clear";
	ApplicationOnComplete["update"] = "update";
	ApplicationOnComplete["delete"] = "delete";
	return ApplicationOnComplete;
}({});
/** Type of signature used by an account */
let SignatureType = /* @__PURE__ */ function(SignatureType) {
	/** Normal signature */
	SignatureType["sig"] = "sig";
	/** Multisig */
	SignatureType["msig"] = "msig";
	/** Logic signature */
	SignatureType["lsig"] = "lsig";
	return SignatureType;
}({});
/** Delegation status of the account */
let AccountStatus = /* @__PURE__ */ function(AccountStatus) {
	/** Indicates that the associated account is delegated */
	AccountStatus["Offline"] = "Offline";
	/** Indicates that the associated account used as part of the delegation pool */
	AccountStatus["Online"] = "Online";
	/** Indicates that the associated account is neither a delegator nor a delegate */
	AccountStatus["NotParticipating"] = "NotParticipating";
	return AccountStatus;
}({});
//#endregion
exports.AccountStatus = AccountStatus;
exports.ApplicationOnComplete = ApplicationOnComplete;
exports.SignatureType = SignatureType;

//# sourceMappingURL=indexer.js.map