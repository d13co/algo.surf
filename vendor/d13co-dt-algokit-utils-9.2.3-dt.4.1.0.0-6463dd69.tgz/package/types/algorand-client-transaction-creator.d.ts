import algosdk from 'algosdk';
import { BuiltTransactions, TransactionComposer } from './composer';
import { Expand } from './expand';
import Transaction = algosdk.Transaction;
/** Orchestrates creating transactions for `AlgorandClient`. */
export declare class AlgorandClientTransactionCreator {
    private _newGroup;
    /**
     * Creates a new `AlgorandClientTransactionCreator`
     * @param newGroup A lambda that starts a new `TransactionComposer` transaction group
     * @example
     * ```typescript
     * const transactionCreator = new AlgorandClientTransactionCreator(() => new TransactionComposer())
     * ```
     */
    constructor(newGroup: () => TransactionComposer);
    private _transaction;
    private _transactions;
    /**
     * Create a payment transaction to transfer Algo between accounts.
     * @param params The parameters for the payment transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.payment({
     *   sender: 'SENDERADDRESS',
     *   receiver: 'RECEIVERADDRESS',
     *   amount: (4).algo(),
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.payment({
     *   amount: (4).algo(),
     *   receiver: 'RECEIVERADDRESS',
     *   sender: 'SENDERADDRESS',
     *   closeRemainderTo: 'CLOSEREMAINDERTOADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The payment transaction
     */
    payment: (params: import("./composer").PaymentParams) => Promise<Transaction>;
    /** Create a create Algorand Standard Asset transaction.
     *
     * The account that sends this transaction will automatically be
     * opted in to the asset and will hold all units after creation.
     *
     * @param params The parameters for the asset creation transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetCreate({ sender: "CREATORADDRESS", total: 100n})
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetCreate({
     *   sender: 'CREATORADDRESS',
     *   total: 100n,
     *   decimals: 2,
     *   assetName: 'asset',
     *   unitName: 'unit',
     *   url: 'url',
     *   metadataHash: 'metadataHash',
     *   defaultFrozen: false,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset create transaction
     */
    assetCreate: (params: import("./composer").AssetCreateParams) => Promise<Transaction>;
    /** Create an asset config transaction to reconfigure an existing Algorand Standard Asset.
     *
     * **Note:** The manager, reserve, freeze, and clawback addresses
     * are immutably empty if they are not set. If manager is not set then
     * all fields are immutable from that point forward.
     *
     * @param params The parameters for the asset config transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetConfig({ sender: "MANAGERADDRESS", assetId: 123456n, manager: "MANAGERADDRESS" })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetConfig({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   manager: 'MANAGERADDRESS',
     *   reserve: 'RESERVEADDRESS',
     *   freeze: 'FREEZEADDRESS',
     *   clawback: 'CLAWBACKADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset config transaction
     */
    assetConfig: (params: import("./composer").AssetConfigParams) => Promise<Transaction>;
    /** Create an Algorand Standard Asset freeze transaction.
     *
     * @param params The parameters for the asset freeze transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetFreeze({ sender: "MANAGERADDRESS", assetId: 123456n, account: "ACCOUNTADDRESS", frozen: true })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetFreeze({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   account: 'ACCOUNTADDRESS',
     *   frozen: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset freeze transaction
     */
    assetFreeze: (params: import("./composer").AssetFreezeParams) => Promise<Transaction>;
    /** Create an Algorand Standard Asset destroy transaction.
     *
     * Created assets can be destroyed only by the asset manager account.
     * All of the assets must be owned by the creator of the asset before
     * the asset can be deleted.
     *
     * @param params The parameters for the asset destroy transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetDestroy({ sender: "MANAGERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetDestroy({
     *   sender: 'MANAGERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset destroy transaction
     */
    assetDestroy: (params: import("./composer").AssetDestroyParams) => Promise<Transaction>;
    /** Create an Algorand Standard Asset transfer transaction.
     *
     * @param params The parameters for the asset transfer transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetTransfer({ sender: "HOLDERADDRESS", assetId: 123456n, amount: 1n, receiver: "RECEIVERADDRESS" })
     * ```
     * @example Advanced example (with clawback)
     * ```typescript
     * await algorand.createTransaction.assetTransfer({
     *   sender: 'CLAWBACKADDRESS',
     *   assetId: 123456n,
     *   amount: 1n,
     *   receiver: 'RECEIVERADDRESS',
     *   clawbackTarget: 'HOLDERADDRESS',
     *   // This field needs to be used with caution
     *   closeAssetTo: 'ADDRESSTOCLOSETO'
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The result of the asset transfer transaction
     */
    assetTransfer: (params: import("./composer").AssetTransferParams) => Promise<Transaction>;
    /** Create an Algorand Standard Asset opt-in transaction.
     *
     * @param params The parameters for the asset opt-in transaction
     *
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.assetOptIn({ sender: "SENDERADDRESS", assetId: 123456n })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetOptIn({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset opt-in transaction
     */
    assetOptIn: (params: import("./composer").AssetOptInParams) => Promise<Transaction>;
    /** Create an asset opt-out transaction.
     *
     * *Note:* If the account has a balance of the asset,
     * it will lose those assets
     *
     * @param params The parameters for the asset opt-out transaction
     *
     * @example Basic example (without creator, will be retrieved from algod)
     * ```typescript
     * await algorand.createTransaction.assetOptOut({ sender: "SENDERADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Basic example (with creator)
     * ```typescript
     * await algorand.createTransaction.assetOptOut({ sender: "SENDERADDRESS", creator: "CREATORADDRESS", assetId: 123456n, ensureZeroBalance: true })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.assetOptOut({
     *   sender: 'SENDERADDRESS',
     *   assetId: 123456n,
     *   creator: 'CREATORADDRESS',
     *   ensureZeroBalance: true,
     *   lease: 'lease',
     *   note: 'note',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The asset opt-out transaction
     */
    assetOptOut: (params: import("./composer").AssetOptOutParams) => Promise<Transaction>;
    /** Create an application create transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app creation transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.appCreate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.appCreate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application create transaction
     */
    appCreate: (params: {
        sender: string | algosdk.Address;
        maxFee?: import("./amount").AlgoAmount | undefined;
        note?: (Uint8Array | string) | undefined;
        args?: Uint8Array[] | undefined;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        onComplete?: algosdk.OnApplicationComplete.NoOpOC | algosdk.OnApplicationComplete.OptInOC | algosdk.OnApplicationComplete.CloseOutOC | algosdk.OnApplicationComplete.UpdateApplicationOC | algosdk.OnApplicationComplete.DeleteApplicationOC | undefined;
        rejectVersion?: number | undefined;
        lease?: (Uint8Array | string) | undefined;
        rekeyTo?: (string | algosdk.Address) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        accountReferences?: (string | algosdk.Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
        schema?: {
            globalInts: number;
            globalByteSlices: number;
            localInts: number;
            localByteSlices: number;
        } | undefined;
        extraProgramPages?: number | undefined;
    }) => Promise<Transaction>;
    /** Create an application update transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app update transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.appUpdate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.appUpdate({
     *  sender: 'CREATORADDRESS',
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application update transaction
     */
    appUpdate: (params: {
        sender: string | algosdk.Address;
        signer?: (algosdk.TransactionSigner | import("./account").TransactionSignerAccount) | undefined;
        rekeyTo?: (string | algosdk.Address) | undefined;
        note?: (Uint8Array | string) | undefined;
        lease?: (Uint8Array | string) | undefined;
        staticFee?: import("./amount").AlgoAmount | undefined;
        extraFee?: import("./amount").AlgoAmount | undefined;
        maxFee?: import("./amount").AlgoAmount | undefined;
        validityWindow?: number | bigint | undefined;
        firstValidRound?: bigint | undefined;
        lastValidRound?: bigint | undefined;
        appId: bigint;
        onComplete?: algosdk.OnApplicationComplete.UpdateApplicationOC | undefined;
        args?: Uint8Array[] | undefined;
        accountReferences?: (string | algosdk.Address)[] | undefined;
        appReferences?: bigint[] | undefined;
        assetReferences?: bigint[] | undefined;
        boxReferences?: (import("./app-manager").BoxReference | import("./app-manager").BoxIdentifier)[] | undefined;
        accessReferences?: import("./app-manager").ResourceReference[] | undefined;
        rejectVersion?: number | undefined;
        approvalProgram: string | Uint8Array;
        clearStateProgram: string | Uint8Array;
    }) => Promise<Transaction>;
    /** Create an application delete transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app deletion transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.appDelete({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.appDelete({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application delete transaction
     */
    appDelete: (params: import("./composer").AppDeleteParams) => Promise<Transaction>;
    /** Create an application call transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app call transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.appCall({ sender: 'CREATORADDRESS' })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.appCall({
     *  sender: 'CREATORADDRESS',
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application call transaction
     */
    appCall: (params: import("./composer").AppCallParams) => Promise<Transaction>;
    /** Create an application create call with ABI method call transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app creation transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appCreateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appCreateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  schema: {
     *    globalInts: 1,
     *    globalByteSlices: 2,
     *    localInts: 3,
     *    localByteSlices: 4
     *  },
     *  extraProgramPages: 1,
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application ABI method create transaction
     */
    appCreateMethodCall: (params: import("./composer").AppCreateMethodCall) => Promise<Expand<BuiltTransactions>>;
    /** Create an application update call with ABI method call transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app update transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appUpdateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appUpdateMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  approvalProgram: "TEALCODE",
     *  clearStateProgram: "TEALCODE",
     *  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application ABI method update transaction
     */
    appUpdateMethodCall: (params: import("./composer").AppUpdateMethodCall) => Promise<Expand<BuiltTransactions>>;
    /** Create an application delete call with ABI method call transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app deletion transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appDeleteMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appDeleteMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application ABI method delete transaction
     */
    appDeleteMethodCall: (params: import("./composer").AppDeleteMethodCall) => Promise<Expand<BuiltTransactions>>;
    /** Create an application call with ABI method call transaction.
     *
     * Note: you may prefer to use `algorand.client` to get an app client for more advanced functionality.
     *
     * @param params The parameters for the app call transaction
     * @example Basic example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appCallMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
     * ```
     * @example Advanced example
     * ```typescript
     * const method = new ABIMethod({
     *   name: 'method',
     *   args: [{ name: 'arg1', type: 'string' }],
     *   returns: { type: 'string' },
     * })
     * await algorand.createTransaction.appCallMethodCall({
     *  sender: 'CREATORADDRESS',
     *  method: method,
     *  args: ["arg1_value"],
     *  onComplete: algosdk.OnApplicationComplete.OptInOC,
     *  args: [new Uint8Array(1, 2, 3, 4)]
     *  accountReferences: ["ACCOUNT_1"]
     *  appReferences: [123n, 1234n]
     *  assetReferences: [12345n]
     *  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
     *  accessReferences: [{ appId: 1234n }]
     *  lease: 'lease',
     *  note: 'note',
     *  // You wouldn't normally set this field
     *  firstValidRound: 1000n,
     *  validityWindow: 10,
     *  extraFee: (1000).microAlgo(),
     *  staticFee: (1000).microAlgo(),
     *  // Max fee doesn't make sense with extraFee AND staticFee
     *  //  already specified, but here for completeness
     *  maxFee: (3000).microAlgo(),
     *  rejectVersion: 1,
     *})
     * ```
     * @returns The application ABI method call transaction
     */
    appCallMethodCall: (params: import("./composer").AppCallMethodCall) => Promise<Expand<BuiltTransactions>>;
    /**
     * Create an online key registration transaction.
     * @param params The parameters for the key registration transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.onlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.onlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
     *   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
     *   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
     *   voteFirst: 1n,
     *   voteLast: 1000n,
     *   voteKeyDilution: 1n,
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The online key registration transaction
     */
    onlineKeyRegistration: (params: import("./composer").OnlineKeyRegistrationParams) => Promise<Transaction>;
    /**
     * Create an offline key registration transaction.
     * @param params The parameters for the key registration transaction
     * @example Basic example
     * ```typescript
     * await algorand.createTransaction.offlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     * })
     * ```
     * @example Advanced example
     * ```typescript
     * await algorand.createTransaction.offlineKeyRegistration({
     *   sender: 'SENDERADDRESS',
     *   lease: 'lease',
     *   note: 'note',
     *   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
     *   rekeyTo: 'REKEYTOADDRESS',
     *   // You wouldn't normally set this field
     *   firstValidRound: 1000n,
     *   validityWindow: 10,
     *   extraFee: (1000).microAlgo(),
     *   staticFee: (1000).microAlgo(),
     *   // Max fee doesn't make sense with extraFee AND staticFee
     *   //  already specified, but here for completeness
     *   maxFee: (3000).microAlgo(),
     * })
     * ```
     * @returns The offline key registration transaction
     */
    offlineKeyRegistration: (params: import("./composer").OfflineKeyRegistrationParams) => Promise<Transaction>;
}
