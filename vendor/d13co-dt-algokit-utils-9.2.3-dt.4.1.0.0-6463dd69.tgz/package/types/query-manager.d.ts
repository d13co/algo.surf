import { Address } from 'algosdk';
import { ABIReturn } from './app';
import { ClientManager } from './client-manager';
import { TransactionComposer } from './composer';
import { QueryLimits, Round, SimulateProtocolOverride } from './dt-support';
import { SimulateGroupsOptions, SimulateManager, SimulateRoundsOptions } from './simulate-manager';
/** The most requests of a query in flight at once, by default. */
export declare const DEFAULT_QUERY_CONCURRENCY = 4;
/** A call of a query: the app args and references of its app call. The references only matter to programs before v9. */
export interface QueryCallParams {
    /** The app args (`ApplicationArgs`). */
    args?: Uint8Array[];
    /** The accounts array. */
    accounts?: (string | Address)[];
    /** The foreign apps array. */
    foreignApps?: Round[];
    /** The foreign assets array. */
    foreignAssets?: Round[];
    /** The box references: `app` 0 (or the called app's ID) for the called or created app. */
    boxes?: {
        app: Round;
        name: Uint8Array;
    }[];
}
/** The state schema of an app created by a query. */
export interface QuerySchema {
    numUint: number;
    numByteSlice: number;
}
/** A read-only query: one program or one app, called once per call at each round. Exactly one of `program` and `appId`. */
export interface QueryParams {
    /** The approval program each call creates an app with (compiled bytes). */
    program?: Uint8Array;
    /** The clear state program of the created apps; the node uses a minimal one when unset. Only with `program`. */
    clearProgram?: Uint8Array;
    /** The global state schema of the created apps. Only with `program`. */
    globalSchema?: QuerySchema;
    /** The local state schema of the created apps. Only with `program`. */
    localSchema?: QuerySchema;
    /** The deployed app each call is a NoOp call of. */
    appId?: Round;
    /** The sender of every call. Defaults to the fee sink. */
    sender?: string | Address;
    /** The rounds to query at (0 for the latest round): the state as of the end of each round. Defaults to the latest round. Duplicates are queried once. */
    rounds?: Round[];
    /**
     * The protocol of the block after each round, as with simulate's `protocol`: by default `latest` (unlike simulate, which
     * runs the round's own), `round` for the protocol the chain really ran, a consensus version or `vNN`, or `future` (needs
     * the developer API). Each result's `protocolOverride` says how it applied (none with `round`).
     */
    protocol?: string;
    /** The opcode budget of each call, inner calls included. Defaults to, and at most, the node's `maxCallBudget`. */
    budget?: number;
    /** The calls, each an app call alone in its group. */
    calls: QueryCallParams[];
}
/** Options for running a query. */
export interface QueryRunOptions {
    /** Aborts the query: every request in flight is cancelled, and the node stops working on it. */
    signal?: AbortSignal;
    /** The most requests in flight at once (default 4). */
    concurrency?: number;
    /** At most this many calls per request. The node's `maxCalls`, and `maxTotalCalls` over the request's rounds, cap it: set it lower to split more. */
    maxCalls?: number;
    /** At most this many rounds per request. The node's `maxRounds` and `maxTotalCalls` cap it: set it lower to split more. */
    maxRounds?: number;
}
/**
 * Why a call of a query has no result:
 * - `round`: the whole round failed (`failureMessage` is the round's error), so no call ran at it;
 * - `call`: the call failed (its program rejected or erred), or its results alone went over the node's response limit or
 *   time limit.
 */
export type QueryCallErrorKind = 'round' | 'call';
/** The failure of one call of a query at one round. */
export declare class QueryCallError extends Error {
    /** Why the call has no result. */
    kind: QueryCallErrorKind;
    /** The index of the call, in the order given. */
    callIndex: number;
    /** The round of the result: the state as of the end of this round. */
    round: bigint;
    /** The node's message, as it sent it. */
    failureMessage: string;
    /** What the call logged before it failed (none for `round`, or when the node returned no result for it). */
    logs: Uint8Array[];
    /** The opcode budget the call used before it failed, when the node returned it. */
    cost?: number;
    constructor({ kind, callIndex, round, failureMessage, logs, cost, }: {
        kind: QueryCallErrorKind;
        callIndex: number;
        round: bigint;
        failureMessage: string;
        logs?: Uint8Array[];
        cost?: number;
    });
}
/** The outcome of one call of a query at one round. */
export type QueryCallOutcome = {
    /** The index of the call, in the order given. */
    callIndex: number;
    /** The round of the result. */
    round: bigint;
} & ({
    ok: true;
    /** What the called (or created) app logged; inner apps' logs aren't included. */
    logs: Uint8Array[];
    /** The opcode budget the call used, inner calls included. */
    cost: number;
} | {
    ok: false;
    error: QueryCallError;
});
/** The results of a query at one round. */
export interface QueryRunResult {
    /** The round: the state as of the end of it. The latest round (0) is resolved to its number. */
    round: bigint;
    /**
     * With `protocol` (other than `round`): how it applied at this round. The notes' `hits` give the call index as `group`, and
     * the path from the call (`path[0]` is 0). Merged across the requests the calls were split into.
     */
    protocolOverride?: SimulateProtocolOverride;
    /** The outcome of each call, in the order given. */
    calls: QueryCallOutcome[];
}
/**
 * Which way `groups` and `rounds` go:
 * - `auto` (the default): query when the node has queries and the groups and options can be queried (see `groups`), else
 *   simulate;
 * - `query`: query, throwing when it can't;
 * - `simulate`: simulate, as `algorand.simulate` with `parallel`.
 */
export type QueryVia = 'auto' | 'query' | 'simulate';
/** How `groups` and `rounds` choose between query and simulate. */
export interface QueryRouting {
    /** Query or simulate (default `auto`). */
    via?: QueryVia;
    /** The most requests in flight at once (default 4), on either path. */
    concurrency?: number;
}
/**
 * Options to query groups at one round: those of `algorand.simulate.groups` (except `parallel`: the groups never see each
 * other) and the routing. On the query path, `maxGroups` and `validityWindow` don't apply, and `allowUnnamedResources`
 * is always on.
 */
export type QueryGroupsOptions = Omit<SimulateGroupsOptions, 'parallel'> & QueryRouting;
/**
 * Options to query groups at several rounds: those of `algorand.simulate.rounds` (except `parallel`) and the routing. On
 * the query path, `maxRounds` (when more than 0) also caps the rounds per query request.
 */
export type QueryRoundsOptions = Omit<SimulateRoundsOptions, 'parallel'> & QueryRouting;
/** The result of a transaction of a queried group. */
export interface QueryTxnResult {
    /** What the transaction's app logged (only the top-level app: inner apps' logs aren't included). Empty for other transactions. */
    logs: Uint8Array[];
    /**
     * The opcode budget the app call used, inner calls included, when the node reported it: the query's `cost` on the query
     * path, simulate's `appBudgetConsumed` on the simulate path.
     */
    cost?: number;
}
/**
 * Why a group has no result:
 * - `round`: the whole round failed (`failureMessage` is the round's error);
 * - `group`: a transaction failed (`failedAt`, `failureMessage`);
 * - `not-simulated` (simulate only): the group wasn't run because an earlier group broke the block;
 * - `missing`: the node returned no result for the group.
 */
export type QueryGroupErrorKind = 'round' | 'group' | 'not-simulated' | 'missing';
/** The failure of a group at a round, from `algorand.query.groups` / `rounds`, on either path. */
export declare class QueryGroupError extends Error {
    /** Why the group has no result. */
    kind: QueryGroupErrorKind;
    /** The index of the group, in the order the composers were given. */
    groupIndex: number;
    /** The round of the result. */
    round: bigint;
    /**
     * The node's message. For a logic error, as simulate words it: `transaction <TXID>: logic eval error: ...` (the query
     * path adds the prefix, with the ID of the transaction as built), so `LogicError` can parse it. A call that was too large
     * or too slow even alone has the node's message as it is.
     */
    failureMessage?: string;
    /** For `group`: the path of the transaction that failed (on the query path, its index in the group). */
    failedAt?: number[];
    /**
     * For `group`: the results of the group's transactions, with the failed one's `error`. On the query path every
     * transaction ran and has one; on the simulate path, the ones that ran before the failure.
     */
    txns?: (QueryTxnResult & {
        error?: string;
    })[];
    constructor({ kind, groupIndex, round, failureMessage, failedAt, txns, cause, }: {
        kind: QueryGroupErrorKind;
        groupIndex: number;
        round: bigint;
        failureMessage?: string;
        failedAt?: number[];
        txns?: (QueryTxnResult & {
            error?: string;
        })[];
        /** On the simulate path, simulate's error */
        cause?: unknown;
    });
}
/** The outcome of one group at one round, from `algorand.query.groups` / `rounds`. */
export type QueryGroupOutcome = {
    /** The index of the group, in the order the composers were given. */
    groupIndex: number;
    /** The round of the result: the state as of the end of it. */
    round: bigint;
    /**
     * With `protocol`: how it applied at this round, the same for every group of the round. The notes' `hits` give the
     * group index and the path in it. Undefined when the round failed.
     */
    protocolOverride?: SimulateProtocolOverride;
    /** Which way the group went. */
    via: 'query' | 'simulate';
} & ({
    ok: true;
    /** The result of each transaction of the group, in order. */
    txns: QueryTxnResult[];
    /** The ABI returns of the group's method calls, in order, as `SendAtomicTransactionComposerResults.returns`. */
    returns: ABIReturn[];
} | {
    ok: false;
    error: QueryGroupError;
});
/** The outcomes of the groups at one round. */
export interface QueryRoundOutcome {
    /** The round, as given. */
    round: bigint;
    /** The outcome of each group, in the order the composers were given. */
    groups: QueryGroupOutcome[];
    /** With `protocol`: how it applied at this round. */
    protocolOverride?: SimulateProtocolOverride;
}
/**
 * Read-only TEAL queries on dtalgod (`POST /v2/query`): many calls of one program or app, each alone, at many rounds, with
 * their logs and cost. No signatures, fees or minimum balances; every resource is available without references; nothing
 * is written.
 *
 * Needs dt-algosdk and a dtalgod with queries on (`MaxAPIQueryCalls` above 0), which its capabilities report.
 */
export declare class QueryManager {
    private _clientManager;
    private _simulate;
    /**
     * Create a new query manager.
     * @param clientManager The `ClientManager` client to use for algod
     * @param simulateManager The `SimulateManager` to fall back to
     */
    constructor(clientManager: ClientManager, simulateManager: SimulateManager);
    /**
     * Returns the node's query limits: how many calls and rounds a request may hold, and calls times rounds
     * (`maxTotalCalls`), the most budget and log bytes of a
     * call, and the most bytes of a response. `run` keeps to them. Undefined when the node has no queries (stock algod, or
     * dtalgod with queries disabled). The limits are asked for once per algod client, with the node's capabilities.
     *
     * @returns The node's query limits, if it has queries
     * @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
     * @example
     * ```typescript
     * const limits = await algorand.query.limits()
     * if (limits) console.log(limits.maxCalls, limits.maxRounds)
     * ```
     */
    limits(): Promise<QueryLimits | undefined>;
    /**
     * Returns whether queries can be used: the loaded algosdk is dt-algosdk, and the node reports query limits. Never throws
     * `DTNotAvailableError`.
     *
     * @returns Whether `run` can be used
     * @example
     * ```typescript
     * if (await algorand.query.supported()) { ... }
     * ```
     */
    supported(): Promise<boolean>;
    /**
     * Runs read-only calls of one program (each call creates an app running it) or one deployed app (each call is a NoOp
     * call of it) at each round, in as few requests as the node's limits allow.
     *
     * Each call is an app call alone in its group, in the block after the round, on the state that round left: no
     * signatures, fees or minimum balances, every resource available without references, and its writes dropped. A failed
     * call doesn't affect the others.
     *
     * The calls and rounds are split into requests by the node's `maxCalls`, `maxRounds` and `maxTotalCalls` (calls times
     * rounds; as many rounds per request as allowed, then as many calls as fit) and by the request body limit,
     * and sent `concurrency` at a time. A request whose results are over the node's `maxResponseBytes`, that runs over
     * its time limit (504), or that a node refuses as over its `maxTotalCalls` (one upgraded since the limits were read),
     * is split in halves (rounds first) and sent again; a call that is still too large or too slow
     * alone fails on its own (`kind: 'call'`). When the latest round (0) is queried in more than one request, it is
     * resolved first so every call sees the same block. A busy node (503) is retried by the HTTP client of an
     * `AlgorandClient` made from a config (`AlgoHttpClientWithRetry`, honoring `Retry-After`). Any other error (a bad
     * request, a round after the latest one) cancels the requests in flight and is thrown.
     *
     * There is no simulate fallback here; `groups` and `rounds` have one.
     *
     * @param params The program or app, the calls, the rounds and the request options
     * @param options How to send the requests
     * @returns The results at each round, in the order of `rounds` (one, at the latest round, without `rounds`)
     * @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
     * @throws dt-algosdk's `DTUnsupportedError` if the node has no queries (stock algod, or dtalgod with queries disabled)
     * @example
     * ```typescript
     * const program = (await algorand.app.compileTeal('#pragma version 10\nglobal Round\nitob\nlog\nint 1')).compiledBase64ToBytes
     * const results = await algorand.query.run({ program, rounds: [0, 50_000_000], protocol: 'round', calls: [{}] })
     * for (const { round, calls: [call] } of results) if (call.ok) console.log(round, call.logs[0])
     *
     * // A deployed app at the latest round
     * const [{ calls }] = await algorand.query.run({ appId: 760937186n, calls: [{ args: [selector] }] })
     * ```
     */
    run(params: QueryParams, options?: QueryRunOptions): Promise<QueryRunResult[]>;
    /**
     * Queries composed app calls at one round (the latest by default), with simulate as the fallback: a drop-in for
     * `algorand.simulate.groups(composers, { parallel: true })` for read-only calls.
     *
     * With query, every app call runs alone, against the round's state: the calls of one group don't see each other (no
     * shared budget pool, `global GroupSize` 1, no `gtxn`), and the composers' fees, validity, notes and leases are ignored;
     * each call gets the node's `maxCallBudget`. With simulate, the groups run as composed, each on its own (`parallel`).
     * So use it for independent read-only calls, such as ghost calls. The protocol defaults to `round` (the round's own,
     * as simulate does).
     *
     * `via: 'auto'` (the default) queries when all of these hold, and simulates otherwise:
     * - the node reports query limits (it has queries on);
     * - `execTraceConfig` is off;
     * - without `allowMoreLogging`, or with the node's `maxCallLogBytes` at least simulate's 65,536;
     * - with `extraOpcodeBudget`, it plus 700 per transaction is at most `maxCallBudget` for every group;
     * - every transaction is a NoOp app call that creates an app (with an approval program) or calls one (without
     *   programs), without an access list or `rejectVersion`, and no method call has transaction arguments.
     *
     * The options are checked the same way whichever path is taken. A node without queries met mid-way (a load balancer
     * mixing nodes) falls back to simulate with `auto`.
     *
     * Unlike `algorand.simulate.groups`, a round the query can't run at gives `kind: 'round'` outcomes (a bad round still
     * fails the whole request).
     *
     * @param composers The groups, one composer each
     * @param options The simulate options and the routing
     * @returns The outcome of each group, in order
     * @example
     * ```typescript
     * const composer = algorand.newGroup().addAppCreateMethodCall({ sender, method, args, approvalProgram, clearStateProgram, schema })
     * const [outcome] = await algorand.query.groups([composer])
     * if (outcome.ok) console.log(outcome.via, outcome.returns[0]?.returnValue, outcome.txns[0].logs)
     * ```
     */
    groups(composers: TransactionComposer[], options?: QueryGroupsOptions): Promise<QueryGroupOutcome[]>;
    /**
     * Queries composed app calls at several past rounds, with simulate as the fallback: a drop-in for
     * `algorand.simulate.rounds(composers, rounds, { parallel: true })` for read-only calls. See `groups` for what query
     * runs and when it is used.
     *
     * @param composers The groups, one composer each (or a single composer)
     * @param rounds The rounds to query at (each > 0): the state as of the end of each round
     * @param options The simulate options and the routing
     * @returns The outcomes at each round, in the order of `rounds`
     * @example
     * ```typescript
     * const composer = algorand.newGroup().addAppCallMethodCall(await appClient.params.call({ method: 'get_price' }))
     * const prices = await algorand.query.rounds(composer, [45_000_000n, 45_001_000n, 45_002_000n])
     * for (const { round, groups: [g] } of prices) if (g.ok) console.log(round, g.returns[0]?.returnValue)
     * ```
     */
    rounds(composers: TransactionComposer | TransactionComposer[], rounds: Round[], options?: QueryRoundsOptions): Promise<QueryRoundOutcome[]>;
    /** Validates the options, then queries or simulates. */
    private composed;
    /** Whether the groups can be queried with these options, with the built groups if so. */
    private queryPlan;
    /** Queries the groups' app calls: one job per target (program or app, and sender), sharing one run. */
    private viaQuery;
    /** Simulates the groups in parallel, as `algorand.simulate` does, and maps the outcomes. */
    private viaSimulate;
    /** A run of query requests within the node's limits. */
    private newRun;
}
