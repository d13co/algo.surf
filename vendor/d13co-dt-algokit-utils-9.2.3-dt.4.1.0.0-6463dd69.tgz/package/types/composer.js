Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_runtime = require("../_virtual/_rolldown/runtime.js");
const require_config = require("../config.js");
require("./lifecycle-events.js");
const require_util = require("../util.js");
const require_resolve_signed_transactions = require("../transaction/resolve-signed-transactions.js");
const require_transaction = require("../transaction/transaction.js");
const require_app_manager = require("./app-manager.js");
const require_network_client = require("./network-client.js");
let algosdk = require("algosdk");
algosdk = require_runtime.__toESM(algosdk);
//#region src/types/composer.ts
var AtomicTransactionComposer = algosdk.default.AtomicTransactionComposer;
var isTransactionWithSigner = algosdk.default.isTransactionWithSigner;
var modelsv2 = algosdk.default.modelsv2;
/**
* The validity window of each build for a simulate at past rounds, keyed by the suggested params object of that build:
* transactions that don't set `firstValidRound` / `lastValidRound` get it instead of one based on the suggested params.
* Kept per build, not per composer, so builds of one composer at different rounds can run concurrently.
*/
const validityWindows = /* @__PURE__ */ new WeakMap();
const address = (address) => {
	return typeof address === "string" ? algosdk.Address.fromString(address) : address;
};
const MAX_TRANSACTION_GROUP_SIZE = 16;
var InvalidErrorTransformerValue = class extends Error {
	constructor(originalError, value) {
		super(`An error transformer returned a non-error value: ${value}. The original error before any transformation: ${originalError}`);
	}
};
var ErrorTransformerError = class extends Error {
	constructor(originalError, cause) {
		super(`An error transformer threw an error: ${cause}. The original error before any transformation: ${originalError} `, { cause });
	}
};
/** TransactionComposer helps you compose and execute transactions as a transaction group. */
var TransactionComposer = class TransactionComposer {
	/** Signer used to represent a lack of signer */
	static NULL_SIGNER = algosdk.default.makeEmptyTransactionSigner();
	/** The ATC used to compose the group */
	atc = new algosdk.default.AtomicTransactionComposer();
	/** Map of transaction index in the atc to a max logical fee.
	* This is set using the value of either maxFee or staticFee.
	*/
	txnMaxFees = /* @__PURE__ */ new Map();
	/** Transactions that have not yet been composed */
	txns = [];
	/** The algod client used by the composer. */
	algod;
	/** An async function that will return suggested params for the transaction. */
	getSuggestedParams;
	/** A function that takes in an address and return a signer function for that address. */
	getSigner;
	/** The default transaction validity window */
	defaultValidityWindow = 10n;
	/** Whether the validity window was explicitly set on construction */
	defaultValidityWindowIsExplicit = false;
	appManager;
	errorTransformers;
	async transformError(originalError) {
		if (!(originalError instanceof Error)) return originalError;
		let transformedError = originalError;
		for (const transformer of this.errorTransformers) try {
			transformedError = await transformer(transformedError);
			if (!(transformedError instanceof Error)) return new InvalidErrorTransformerValue(originalError, transformedError);
		} catch (errorFromTransformer) {
			return new ErrorTransformerError(originalError, errorFromTransformer);
		}
		return transformedError;
	}
	/**
	* Create a `TransactionComposer`.
	* @param params The configuration for this composer
	* @returns The `TransactionComposer` instance
	*/
	constructor(params) {
		this.algod = params.algod;
		const defaultGetSuggestedParams = () => params.algod.getTransactionParams().do();
		this.getSuggestedParams = params.getSuggestedParams ?? defaultGetSuggestedParams;
		this.getSigner = params.getSigner;
		this.defaultValidityWindow = params.defaultValidityWindow ?? this.defaultValidityWindow;
		this.defaultValidityWindowIsExplicit = params.defaultValidityWindow !== void 0;
		this.appManager = params.appManager ?? new require_app_manager.AppManager(params.algod);
		this.errorTransformers = params.errorTransformers ?? [];
	}
	/**
	* Register a function that will be used to transform an error caught when simulating or executing
	*
	* @returns The composer so you can chain method calls
	*/
	registerErrorTransformer(transformer) {
		this.errorTransformers.push(transformer);
		return this;
	}
	/**
	* Add a pre-built transaction to the transaction group.
	* @param transaction The pre-built transaction
	* @param signer Optional signer override for the transaction
	* @returns The composer so you can chain method calls
	* @example
	* ```typescript
	* composer.addTransaction(txn)
	* ```
	*/
	addTransaction(transaction, signer) {
		this.txns.push({
			txn: transaction,
			signer: signer ?? this.getSigner(transaction.sender),
			type: "txnWithSigner"
		});
		return this;
	}
	/**
	* Add a payment transaction to the transaction group.
	* @param params The payment transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addPayment({
	*   sender: 'SENDERADDRESS',
	*   receiver: 'RECEIVERADDRESS',
	*   amount: (4).algo(),
	* })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addPayment({
	*   amount: (4).algo(),
	*   receiver: 'RECEIVERADDRESS',
	*   sender: 'SENDERADDRESS',
	*   closeRemainderTo: 'CLOSEREMAINDERTOADDRESS',
	*   lease: 'lease',
	*   note: 'note',
	*   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
	*   rekeyTo: 'REKEYTOADDRESS',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	*/
	addPayment(params) {
		this.txns.push({
			...params,
			type: "pay"
		});
		return this;
	}
	/**
	* Add an asset create transaction to the transaction group.
	* @param params The asset create transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetCreate({ sender: "CREATORADDRESS", total: 100n})
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetCreate({
	*   sender: 'CREATORADDRESS',
	*   total: 100n,
	*   decimals: 2,
	*   assetName: 'asset',
	*   unitName: 'unit',
	*   url: 'url',
	*   metadataHash: 'metadataHash',
	*   defaultFrozen: false,
	*   manager: 'MANAGERADDRESS',
	*   reserve: 'RESERVEADDRESS',
	*   freeze: 'FREEZEADDRESS',
	*   clawback: 'CLAWBACKADDRESS',
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	*/
	addAssetCreate(params) {
		this.txns.push({
			...params,
			type: "assetCreate"
		});
		return this;
	}
	/**
	* Add an asset config transaction to the transaction group.
	* @param params The asset config transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetConfig({ sender: "MANAGERADDRESS", assetId: 123456n, manager: "MANAGERADDRESS" })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetConfig({
	*   sender: 'MANAGERADDRESS',
	*   assetId: 123456n,
	*   manager: 'MANAGERADDRESS',
	*   reserve: 'RESERVEADDRESS',
	*   freeze: 'FREEZEADDRESS',
	*   clawback: 'CLAWBACKADDRESS',
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	*/
	addAssetConfig(params) {
		this.txns.push({
			...params,
			type: "assetConfig"
		});
		return this;
	}
	/**
	* Add an asset freeze transaction to the transaction group.
	* @param params The asset freeze transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetFreeze({ sender: "MANAGERADDRESS", assetId: 123456n, account: "ACCOUNTADDRESS", frozen: true })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetFreeze({
	*   sender: 'MANAGERADDRESS',
	*   assetId: 123456n,
	*   account: 'ACCOUNTADDRESS',
	*   frozen: true,
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addAssetFreeze(params) {
		this.txns.push({
			...params,
			type: "assetFreeze"
		});
		return this;
	}
	/**
	* Add an asset destroy transaction to the transaction group.
	* @param params The asset destroy transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetDestroy({ sender: "MANAGERADDRESS", assetId: 123456n })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetDestroy({
	*   sender: 'MANAGERADDRESS',
	*   assetId: 123456n,
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addAssetDestroy(params) {
		this.txns.push({
			...params,
			type: "assetDestroy"
		});
		return this;
	}
	/**
	* Add an asset transfer transaction to the transaction group.
	* @param params The asset transfer transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetTransfer({ sender: "HOLDERADDRESS", assetId: 123456n, amount: 1n, receiver: "RECEIVERADDRESS" })
	* ```
	* @example Advanced example (with clawback)
	* ```typescript
	* composer.addAssetTransfer({
	*   sender: 'CLAWBACKADDRESS',
	*   assetId: 123456n,
	*   amount: 1n,
	*   receiver: 'RECEIVERADDRESS',
	*   clawbackTarget: 'HOLDERADDRESS',
	*   // This field needs to be used with caution
	*   closeAssetTo: 'ADDRESSTOCLOSETO'
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addAssetTransfer(params) {
		this.txns.push({
			...params,
			type: "assetTransfer"
		});
		return this;
	}
	/**
	* Add an asset opt-in transaction to the transaction group.
	* @param params The asset opt-in transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAssetOptIn({ sender: "SENDERADDRESS", assetId: 123456n })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetOptIn({
	*   sender: 'SENDERADDRESS',
	*   assetId: 123456n,
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addAssetOptIn(params) {
		this.txns.push({
			...params,
			type: "assetOptIn"
		});
		return this;
	}
	/**
	* Add an asset opt-out transaction to the transaction group.
	* @param params The asset opt-out transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example (without creator, will be retrieved from algod)
	* ```typescript
	* composer.addAssetOptOut({ sender: "SENDERADDRESS", assetId: 123456n, ensureZeroBalance: true })
	* ```
	* @example Basic example (with creator)
	* ```typescript
	* composer.addAssetOptOut({ sender: "SENDERADDRESS", creator: "CREATORADDRESS", assetId: 123456n, ensureZeroBalance: true })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAssetOptOut({
	*   sender: 'SENDERADDRESS',
	*   assetId: 123456n,
	*   creator: 'CREATORADDRESS',
	*   ensureZeroBalance: true,
	*   lease: 'lease',
	*   note: 'note',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addAssetOptOut(params) {
		this.txns.push({
			...params,
			type: "assetOptOut"
		});
		return this;
	}
	/**
	* Add an application create transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The application create transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAppCreate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAppCreate({
	*  sender: 'CREATORADDRESS',
	*  approvalProgram: "TEALCODE",
	*  clearStateProgram: "TEALCODE",
	*  schema: {
	*    globalInts: 1,
	*    globalByteSlices: 2,
	*    localInts: 3,
	*    localByteSlices: 4
	*  },
	*  extraProgramPages: 1,
	*  onComplete: algosdk.OnApplicationComplete.OptInOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*  // Signer only needed if you want to provide one,
	*  //  generally you'd register it with AlgorandClient
	*  //  against the sender and not need to pass it in
	*  signer: transactionSigner,
	*  maxRoundsToWaitForConfirmation: 5,
	*  suppressLog: true,
	*})
	* ```
	*/
	addAppCreate(params) {
		this.txns.push({
			...params,
			type: "appCall"
		});
		return this;
	}
	/**
	* Add an application update transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The application update transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAppUpdate({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE' })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAppUpdate({
	*  sender: 'CREATORADDRESS',
	*  approvalProgram: "TEALCODE",
	*  clearStateProgram: "TEALCODE",
	*  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppUpdate(params) {
		this.txns.push({
			...params,
			type: "appCall",
			onComplete: algosdk.default.OnApplicationComplete.UpdateApplicationOC
		});
		return this;
	}
	/**
	* Add an application delete transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The application delete transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAppDelete({ sender: 'CREATORADDRESS' })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAppDelete({
	*  sender: 'CREATORADDRESS',
	*  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppDelete(params) {
		this.txns.push({
			...params,
			type: "appCall",
			onComplete: algosdk.default.OnApplicationComplete.DeleteApplicationOC
		});
		return this;
	}
	/**
	* Add an application call transaction to the transaction group.
	*
	* If you want to create or update an app use `addAppCreate` or `addAppUpdate`.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The application call transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addAppCall({ sender: 'CREATORADDRESS' })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addAppCall({
	*  sender: 'CREATORADDRESS',
	*  onComplete: algosdk.OnApplicationComplete.OptInOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppCall(params) {
		this.txns.push({
			...params,
			type: "appCall"
		});
		return this;
	}
	/**
	* Add an ABI method create application call transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The ABI create method application call transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppCreateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
	* ```
	* @example Advanced example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppCreateMethodCall({
	*  sender: 'CREATORADDRESS',
	*  method: method,
	*  args: ["arg1_value"],
	*  approvalProgram: "TEALCODE",
	*  clearStateProgram: "TEALCODE",
	*  schema: {
	*    globalInts: 1,
	*    globalByteSlices: 2,
	*    localInts: 3,
	*    localByteSlices: 4
	*  },
	*  extraProgramPages: 1,
	*  onComplete: algosdk.OnApplicationComplete.OptInOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppCreateMethodCall(params) {
		this.txns.push({
			...params,
			type: "methodCall"
		});
		return this;
	}
	/**
	* Add an ABI method update application call transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The ABI update method application call transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppUpdateMethodCall({ sender: 'CREATORADDRESS', approvalProgram: 'TEALCODE', clearStateProgram: 'TEALCODE', method: method, args: ["arg1_value"] })
	* ```
	* @example Advanced example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppUpdateMethodCall({
	*  sender: 'CREATORADDRESS',
	*  method: method,
	*  args: ["arg1_value"],
	*  approvalProgram: "TEALCODE",
	*  clearStateProgram: "TEALCODE",
	*  onComplete: algosdk.OnApplicationComplete.UpdateApplicationOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppUpdateMethodCall(params) {
		this.txns.push({
			...params,
			type: "methodCall",
			onComplete: algosdk.default.OnApplicationComplete.UpdateApplicationOC
		});
		return this;
	}
	/**
	* Add an ABI method delete application call transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The ABI delete method application call transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppDeleteMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
	* ```
	* @example Advanced example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppDeleteMethodCall({
	*  sender: 'CREATORADDRESS',
	*  method: method,
	*  args: ["arg1_value"],
	*  onComplete: algosdk.OnApplicationComplete.DeleteApplicationOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppDeleteMethodCall(params) {
		this.txns.push({
			...params,
			type: "methodCall",
			onComplete: algosdk.default.OnApplicationComplete.DeleteApplicationOC
		});
		return this;
	}
	/**
	* Add a non-create/non-update ABI method application call transaction to the transaction group.
	*
	* Note: we recommend using app clients to make it easier to make app calls.
	* @param params The ABI method application call transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppCallMethodCall({ sender: 'CREATORADDRESS', method: method, args: ["arg1_value"] })
	* ```
	* @example Advanced example
	* ```typescript
	* const method = new ABIMethod({
	*   name: 'method',
	*   args: [{ name: 'arg1', type: 'string' }],
	*   returns: { type: 'string' },
	* })
	* composer.addAppCallMethodCall({
	*  sender: 'CREATORADDRESS',
	*  method: method,
	*  args: ["arg1_value"],
	*  onComplete: algosdk.OnApplicationComplete.OptInOC,
	*  args: [new Uint8Array(1, 2, 3, 4)]
	*  accountReferences: ["ACCOUNT_1"]
	*  appReferences: [123n, 1234n]
	*  assetReferences: [12345n]
	*  boxReferences: ["box1", {appId: 1234n, name: "box2"}]
	*  accessReferences: [{ appId: 1234n }]
	*  lease: 'lease',
	*  note: 'note',
	*  // You wouldn't normally set this field
	*  firstValidRound: 1000n,
	*  validityWindow: 10,
	*  extraFee: (1000).microAlgo(),
	*  staticFee: (1000).microAlgo(),
	*  // Max fee doesn't make sense with extraFee AND staticFee
	*  //  already specified, but here for completeness
	*  maxFee: (3000).microAlgo(),
	*  rejectVersion: 1,
	*})
	* ```
	*/
	addAppCallMethodCall(params) {
		this.txns.push({
			...params,
			type: "methodCall"
		});
		return this;
	}
	/**
	* Add an online key registration transaction to the transaction group.
	* @param params The online key registration transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addOnlineKeyRegistration({
	*   sender: 'SENDERADDRESS',
	*   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
	*   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
	*   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
	*   voteFirst: 1n,
	*   voteLast: 1000n,
	*   voteKeyDilution: 1n,
	* })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addOnlineKeyRegistration({
	*   sender: 'SENDERADDRESS',
	*   voteKey: Uint8Array.from(Buffer.from("voteKeyBase64", 'base64')),
	*   selectionKey: Uint8Array.from(Buffer.from("selectionKeyBase64", 'base64')),
	*   stateProofKey: Uint8Array.from(Buffer.from("stateProofKeyBase64", 'base64')),
	*   voteFirst: 1n,
	*   voteLast: 1000n,
	*   voteKeyDilution: 1n,
	*   lease: 'lease',
	*   note: 'note',
	*   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
	*   rekeyTo: 'REKEYTOADDRESS',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addOnlineKeyRegistration(params) {
		this.txns.push({
			...params,
			type: "keyReg"
		});
		return this;
	}
	/**
	* Add an offline key registration transaction to the transaction group.
	* @param params The offline key registration transaction parameters
	* @returns The composer so you can chain method calls
	* @example Basic example
	* ```typescript
	* composer.addOfflineKeyRegistration({
	*   sender: 'SENDERADDRESS',
	* })
	* ```
	* @example Advanced example
	* ```typescript
	* composer.addOfflineKeyRegistration({
	*   sender: 'SENDERADDRESS',
	*   lease: 'lease',
	*   note: 'note',
	*   // Use this with caution, it's generally better to use algorand.account.rekeyAccount
	*   rekeyTo: 'REKEYTOADDRESS',
	*   // You wouldn't normally set this field
	*   firstValidRound: 1000n,
	*   validityWindow: 10,
	*   extraFee: (1000).microAlgo(),
	*   staticFee: (1000).microAlgo(),
	*   // Max fee doesn't make sense with extraFee AND staticFee
	*   //  already specified, but here for completeness
	*   maxFee: (3000).microAlgo(),
	* })
	* ```
	*/
	addOfflineKeyRegistration(params) {
		this.txns.push({
			...params,
			type: "keyReg"
		});
		return this;
	}
	/**
	* Add the transactions within an `AtomicTransactionComposer` to the transaction group.
	* @param atc The `AtomicTransactionComposer` to build transactions from and add to the group
	* @returns The composer so you can chain method calls
	* @example
	* ```typescript
	* const atc = new AtomicTransactionComposer()
	*   .addPayment({ sender: 'SENDERADDRESS', receiver: 'RECEIVERADDRESS', amount: 1000n })
	* composer.addAtc(atc)
	* ```
	*/
	addAtc(atc) {
		this.txns.push({
			atc,
			type: "atc"
		});
		return this;
	}
	/** Build an ATC and return transactions ready to be incorporated into a broader set of transactions this composer is composing */
	buildAtc(atc) {
		return atc.buildGroup().map((ts, idx) => {
			ts.txn.group = void 0;
			if (atc["methodCalls"].get(idx)) return {
				...ts,
				context: { abiMethod: atc["methodCalls"].get(idx) }
			};
			return {
				...ts,
				context: {}
			};
		});
	}
	commonTxnBuildStep(buildTxn, params, txnParams) {
		const validityWindow = validityWindows.get(txnParams.suggestedParams);
		txnParams.suggestedParams = { ...txnParams.suggestedParams };
		if (params.lease) txnParams.lease = require_transaction.encodeLease(params.lease);
		if (params.rekeyTo) txnParams.rekeyTo = address(params.rekeyTo);
		const encoder = new TextEncoder();
		if (params.note) txnParams.note = typeof params.note === "string" ? encoder.encode(params.note) : params.note;
		if (validityWindow && !params.firstValidRound && !params.lastValidRound) {
			txnParams.suggestedParams.firstValid = validityWindow.firstValid;
			txnParams.suggestedParams.lastValid = validityWindow.lastValid;
		} else {
			if (params.firstValidRound) txnParams.suggestedParams.firstValid = params.firstValidRound;
			if (params.lastValidRound) txnParams.suggestedParams.lastValid = params.lastValidRound;
			else {
				const window = params.validityWindow ? BigInt(params.validityWindow) : !this.defaultValidityWindowIsExplicit && require_network_client.genesisIdIsLocalNet(txnParams.suggestedParams.genesisID ?? "unknown") ? 1000n : this.defaultValidityWindow;
				txnParams.suggestedParams.lastValid = BigInt(txnParams.suggestedParams.firstValid) + window;
			}
		}
		if (params.staticFee !== void 0 && params.extraFee !== void 0) throw Error("Cannot set both staticFee and extraFee");
		if (params.staticFee !== void 0) {
			txnParams.suggestedParams.fee = params.staticFee.microAlgo;
			txnParams.suggestedParams.flatFee = true;
		}
		const txn = buildTxn(txnParams);
		if (params.extraFee) txn.fee += params.extraFee.microAlgo;
		if (params.maxFee !== void 0 && txn.fee > params.maxFee.microAlgo) throw Error(`Transaction fee ${txn.fee} µALGO is greater than maxFee ${params.maxFee}`);
		return {
			txn,
			context: { maxFee: params.maxFee !== void 0 && params.maxFee.microAlgo > (params.staticFee?.microAlgo ?? 0n) ? params.maxFee : params.staticFee }
		};
	}
	/**
	* Builds an ABI method call transaction and any other associated transactions represented in the ABI args.
	* @param includeSigner Whether to include the actual signer for the transactions.
	*  If you are just building transactions without signers yet then set this to `false`.
	*/
	async buildMethodCall(params, suggestedParams, includeSigner) {
		const methodArgs = [];
		const transactionsForGroup = [];
		const isAbiValue = (x) => {
			if (Array.isArray(x)) return x.length == 0 || x.every(isAbiValue);
			return typeof x === "bigint" || typeof x === "boolean" || typeof x === "number" || typeof x === "string" || x instanceof Uint8Array || x instanceof algosdk.default.Address;
		};
		for (let i = (params.args ?? []).length - 1; i >= 0; i--) {
			const arg = params.args[i];
			if (arg === void 0) {
				if (algosdk.default.abiTypeIsTransaction(params.method.args[i].type) && transactionsForGroup.length > 0) {
					const placeholderTransaction = transactionsForGroup.splice(-1, 1)[0];
					methodArgs.push(placeholderTransaction);
					continue;
				}
				throw Error(`No value provided for argument ${i + 1} within call to ${params.method.name}`);
			}
			if (isAbiValue(arg)) {
				methodArgs.push(arg);
				continue;
			}
			if (isTransactionWithSigner(arg)) {
				methodArgs.push(arg);
				continue;
			}
			if ("method" in arg) {
				const tempTxnWithSigners = await this.buildMethodCall(arg, suggestedParams, includeSigner);
				methodArgs.push(...tempTxnWithSigners.slice(-1));
				transactionsForGroup.push(...tempTxnWithSigners.slice(0, -1).reverse());
				continue;
			}
			const txn = await arg;
			methodArgs.push({
				txn,
				signer: includeSigner ? params.signer ? "signer" in params.signer ? params.signer.signer : params.signer : this.getSigner(txn.sender) : TransactionComposer.NULL_SIGNER
			});
		}
		const methodAtc = new algosdk.default.AtomicTransactionComposer();
		const maxFees = /* @__PURE__ */ new Map();
		transactionsForGroup.reverse().forEach(({ context, ...txnWithSigner }) => {
			methodAtc.addTransaction(txnWithSigner);
			const atcIndex = methodAtc.count() - 1;
			if (context.abiMethod) methodAtc["methodCalls"].set(atcIndex, context.abiMethod);
			if (context.maxFee !== void 0) maxFees.set(atcIndex, context.maxFee);
		});
		methodArgs.filter((arg) => {
			if (typeof arg === "object" && "context" in arg) {
				const { context, ...txnWithSigner } = arg;
				return isTransactionWithSigner(txnWithSigner);
			}
			return isTransactionWithSigner(arg);
		}).reverse().forEach((arg, idx) => {
			if (typeof arg === "object" && "context" in arg && arg.context) {
				const atcIndex = methodAtc.count() + idx;
				if (arg.context.abiMethod) methodAtc["methodCalls"].set(atcIndex, arg.context.abiMethod);
				if (arg.context.maxFee !== void 0) maxFees.set(atcIndex, arg.context.maxFee);
			}
		});
		const appId = Number("appId" in params ? params.appId : 0n);
		const approvalProgram = "approvalProgram" in params ? typeof params.approvalProgram === "string" ? (await this.appManager.compileTeal(params.approvalProgram)).compiledBase64ToBytes : params.approvalProgram : void 0;
		const clearStateProgram = "clearStateProgram" in params ? typeof params.clearStateProgram === "string" ? (await this.appManager.compileTeal(params.clearStateProgram)).compiledBase64ToBytes : params.clearStateProgram : void 0;
		const txnParams = {
			appID: appId,
			sender: params.sender,
			suggestedParams,
			onComplete: params.onComplete ?? algosdk.default.OnApplicationComplete.NoOpOC,
			appAccounts: params.accountReferences,
			appForeignApps: params.appReferences?.map((x) => Number(x)),
			appForeignAssets: params.assetReferences?.map((x) => Number(x)),
			boxes: params.boxReferences?.map(require_app_manager.AppManager.getBoxReference),
			access: params.accessReferences?.map(getResourceReference),
			approvalProgram,
			clearProgram: clearStateProgram,
			extraPages: appId === 0 ? "extraProgramPages" in params && params.extraProgramPages !== void 0 ? params.extraProgramPages : approvalProgram ? require_util.calculateExtraProgramPages(approvalProgram, clearStateProgram) : 0 : void 0,
			numLocalInts: appId === 0 ? "schema" in params ? params.schema?.localInts ?? 0 : 0 : void 0,
			numLocalByteSlices: appId === 0 ? "schema" in params ? params.schema?.localByteSlices ?? 0 : 0 : void 0,
			numGlobalInts: appId === 0 ? "schema" in params ? params.schema?.globalInts ?? 0 : 0 : void 0,
			numGlobalByteSlices: appId === 0 ? "schema" in params ? params.schema?.globalByteSlices ?? 0 : 0 : void 0,
			method: params.method,
			signer: includeSigner ? params.signer ? "signer" in params.signer ? params.signer.signer : params.signer : this.getSigner(params.sender) : TransactionComposer.NULL_SIGNER,
			methodArgs: methodArgs.map((arg) => {
				if (typeof arg === "object" && "context" in arg) {
					const { context, ...txnWithSigner } = arg;
					return txnWithSigner;
				}
				return arg;
			}).reverse(),
			rejectVersion: params.rejectVersion,
			note: void 0,
			lease: void 0,
			rekeyTo: void 0
		};
		const result = this.commonTxnBuildStep((txnParams) => {
			methodAtc.addMethodCall(txnParams);
			return methodAtc.buildGroup()[methodAtc.count() - 1].txn;
		}, params, txnParams);
		return this.buildAtc(methodAtc).map(({ context: _context, ...txnWithSigner }, idx) => {
			const maxFee = idx === methodAtc.count() - 1 ? result.context.maxFee : maxFees.get(idx);
			const context = {
				..._context,
				maxFee
			};
			return {
				...txnWithSigner,
				context
			};
		});
	}
	buildPayment(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makePaymentTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			receiver: params.receiver,
			amount: params.amount.microAlgo,
			closeRemainderTo: params.closeRemainderTo,
			suggestedParams
		});
	}
	buildAssetCreate(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makeAssetCreateTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			total: params.total,
			decimals: params.decimals ?? 0,
			assetName: params.assetName,
			unitName: params.unitName,
			assetURL: params.url,
			defaultFrozen: params.defaultFrozen ?? false,
			assetMetadataHash: typeof params.metadataHash === "string" ? Buffer.from(params.metadataHash, "utf-8") : params.metadataHash,
			manager: params.manager,
			reserve: params.reserve,
			freeze: params.freeze,
			clawback: params.clawback,
			suggestedParams
		});
	}
	buildAssetConfig(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makeAssetConfigTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			assetIndex: params.assetId,
			suggestedParams,
			manager: params.manager,
			reserve: params.reserve,
			freeze: params.freeze,
			clawback: params.clawback,
			strictEmptyAddressChecking: false
		});
	}
	buildAssetDestroy(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makeAssetDestroyTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			assetIndex: params.assetId,
			suggestedParams
		});
	}
	buildAssetFreeze(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makeAssetFreezeTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			assetIndex: params.assetId,
			freezeTarget: params.account,
			frozen: params.frozen,
			suggestedParams
		});
	}
	buildAssetTransfer(params, suggestedParams) {
		return this.commonTxnBuildStep(algosdk.default.makeAssetTransferTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			receiver: params.receiver,
			assetIndex: params.assetId,
			amount: params.amount,
			suggestedParams,
			closeRemainderTo: params.closeAssetTo,
			assetSender: params.clawbackTarget
		});
	}
	async buildAppCall(params, suggestedParams) {
		const appId = "appId" in params ? params.appId : 0n;
		const approvalProgram = "approvalProgram" in params ? typeof params.approvalProgram === "string" ? (await this.appManager.compileTeal(params.approvalProgram)).compiledBase64ToBytes : params.approvalProgram : void 0;
		const clearStateProgram = "clearStateProgram" in params ? typeof params.clearStateProgram === "string" ? (await this.appManager.compileTeal(params.clearStateProgram)).compiledBase64ToBytes : params.clearStateProgram : void 0;
		const sdkParams = {
			sender: params.sender,
			suggestedParams,
			appArgs: params.args,
			onComplete: params.onComplete ?? algosdk.default.OnApplicationComplete.NoOpOC,
			accounts: params.accountReferences,
			foreignApps: params.appReferences?.map((x) => Number(x)),
			foreignAssets: params.assetReferences?.map((x) => Number(x)),
			boxes: params.boxReferences?.map(require_app_manager.AppManager.getBoxReference),
			access: params.accessReferences?.map(getResourceReference),
			approvalProgram,
			clearProgram: clearStateProgram,
			rejectVersion: params.rejectVersion
		};
		if (appId === 0n) {
			if (sdkParams.approvalProgram === void 0 || sdkParams.clearProgram === void 0) throw new Error("approvalProgram and clearStateProgram are required for application creation");
			return this.commonTxnBuildStep(algosdk.default.makeApplicationCreateTxnFromObject, params, {
				...sdkParams,
				extraPages: "extraProgramPages" in params && params.extraProgramPages !== void 0 ? params.extraProgramPages : require_util.calculateExtraProgramPages(approvalProgram, clearStateProgram),
				numLocalInts: "schema" in params ? params.schema?.localInts ?? 0 : 0,
				numLocalByteSlices: "schema" in params ? params.schema?.localByteSlices ?? 0 : 0,
				numGlobalInts: "schema" in params ? params.schema?.globalInts ?? 0 : 0,
				numGlobalByteSlices: "schema" in params ? params.schema?.globalByteSlices ?? 0 : 0,
				approvalProgram,
				clearProgram: clearStateProgram
			});
		} else return this.commonTxnBuildStep(algosdk.default.makeApplicationCallTxnFromObject, params, {
			...sdkParams,
			appIndex: appId
		});
	}
	buildKeyReg(params, suggestedParams) {
		if ("voteKey" in params) return this.commonTxnBuildStep(algosdk.default.makeKeyRegistrationTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			voteKey: params.voteKey,
			selectionKey: params.selectionKey,
			voteFirst: params.voteFirst,
			voteLast: params.voteLast,
			voteKeyDilution: params.voteKeyDilution,
			suggestedParams,
			nonParticipation: false,
			stateProofKey: params.stateProofKey
		});
		return this.commonTxnBuildStep(algosdk.default.makeKeyRegistrationTxnWithSuggestedParamsFromObject, params, {
			sender: params.sender,
			suggestedParams,
			nonParticipation: params.preventAccountFromEverParticipatingAgain
		});
	}
	/** Builds all transaction types apart from `txnWithSigner`, `atc` and `methodCall` since those ones can have custom signers that need to be retrieved. */
	async buildTxn(txn, suggestedParams) {
		switch (txn.type) {
			case "pay": return [this.buildPayment(txn, suggestedParams)];
			case "assetCreate": return [this.buildAssetCreate(txn, suggestedParams)];
			case "appCall": return [await this.buildAppCall(txn, suggestedParams)];
			case "assetConfig": return [this.buildAssetConfig(txn, suggestedParams)];
			case "assetDestroy": return [this.buildAssetDestroy(txn, suggestedParams)];
			case "assetFreeze": return [this.buildAssetFreeze(txn, suggestedParams)];
			case "assetTransfer": return [this.buildAssetTransfer(txn, suggestedParams)];
			case "assetOptIn": return [this.buildAssetTransfer({
				...txn,
				receiver: txn.sender,
				amount: 0n
			}, suggestedParams)];
			case "assetOptOut": return [this.buildAssetTransfer({
				...txn,
				receiver: txn.sender,
				amount: 0n,
				closeAssetTo: txn.creator
			}, suggestedParams)];
			case "keyReg": return [this.buildKeyReg(txn, suggestedParams)];
			default: throw Error(`Unsupported txn type`);
		}
	}
	async buildTxnWithSigner(txn, suggestedParams) {
		if (txn.type === "txnWithSigner") return [{
			...txn,
			context: {}
		}];
		if (txn.type === "atc") return this.buildAtc(txn.atc);
		if (txn.type === "methodCall") return await this.buildMethodCall(txn, suggestedParams, true);
		const signer = txn.signer ? "signer" in txn.signer ? txn.signer.signer : txn.signer : this.getSigner(txn.sender);
		return (await this.buildTxn(txn, suggestedParams)).map(({ txn, context }) => ({
			txn,
			signer,
			context
		}));
	}
	/**
	* Compose all of the transactions without signers and return the transaction objects directly along with any ABI method calls.
	*
	* @returns The array of built transactions and any corresponding method calls
	* @example
	* ```typescript
	* const { transactions, methodCalls, signers } = await composer.buildTransactions()
	* ```
	*/
	async buildTransactions() {
		return await this.buildTransactionsIn();
	}
	/** Returns the suggested params for one build, carrying `validity` (for a simulate at past rounds) when given. */
	async suggestedParamsFor(validity) {
		const suggestedParams = await this.getSuggestedParams();
		if (!validity) return suggestedParams;
		const own = { ...suggestedParams };
		validityWindows.set(own, validity);
		return own;
	}
	/** `buildTransactions`, valid in `validity` when given. */
	async buildTransactionsIn(validity) {
		const suggestedParams = await this.suggestedParamsFor(validity);
		const transactions = [];
		const methodCalls = /* @__PURE__ */ new Map();
		const signers = /* @__PURE__ */ new Map();
		for (const txn of this.txns) if (![
			"txnWithSigner",
			"atc",
			"methodCall"
		].includes(txn.type)) transactions.push(...(await this.buildTxn(txn, suggestedParams)).map((txn) => txn.txn));
		else (txn.type === "txnWithSigner" ? [txn] : txn.type === "atc" ? this.buildAtc(txn.atc) : txn.type === "methodCall" ? await this.buildMethodCall(txn, suggestedParams, false) : []).forEach((ts) => {
			transactions.push(ts.txn);
			const groupIdx = transactions.length - 1;
			if (ts.signer && ts.signer !== TransactionComposer.NULL_SIGNER) signers.set(groupIdx, ts.signer);
			if ("context" in ts && ts.context.abiMethod) methodCalls.set(groupIdx, ts.context.abiMethod);
		});
		return {
			transactions,
			methodCalls,
			signers
		};
	}
	/**
	* Compose all of the transactions without signers, like `buildTransactions`, but valid from `firstValidRound` to
	* `lastValidRound`: transactions that set their own `firstValidRound` or `lastValidRound` keep them, the others get
	* this window. Use this to build transactions for a simulate at past rounds, which needs them valid at those rounds
	* (a simulate at round R runs the transactions in round R + 1).
	*
	* Transactions added already built (`addTransaction`, `addAtc`) keep their own validity.
	*
	* @param validity The validity window to build with
	* @returns The built transactions, method calls and signers
	* @example
	* ```typescript
	* const { transactions } = await composer.buildTransactionsWithValidity({ firstValidRound: 1001n, lastValidRound: 1011n })
	* ```
	*/
	async buildTransactionsWithValidity(validity) {
		if (validity.lastValidRound < validity.firstValidRound) throw new Error(`lastValidRound ${validity.lastValidRound} is before firstValidRound ${validity.firstValidRound}`);
		return await this.buildTransactionsIn({
			firstValid: validity.firstValidRound,
			lastValid: validity.lastValidRound
		});
	}
	/** The validity window for a simulate at `round`, or `undefined` for 0 / undefined (the latest round). */
	validityForSimulateRound(round) {
		if (!round) return void 0;
		const firstValid = BigInt(round) + 1n;
		return {
			firstValid,
			lastValid: firstValid + this.defaultValidityWindow
		};
	}
	/**
	* Get the number of transactions currently added to this composer.
	* @returns The number of transactions currently added to this composer
	*/
	async count() {
		return (await this.buildTransactions()).transactions.length;
	}
	/**
	* Compose all of the transactions in a single atomic transaction group and an atomic transaction composer.
	*
	* You can then use the transactions standalone, or use the composer to execute or simulate the transactions.
	*
	* Once this method is called, no further transactions will be able to be added.
	* You can safely call this method multiple times to get the same result.
	* @returns The built atomic transaction composer, the transactions and any corresponding method calls
	* @example
	* ```typescript
	* const { atc, transactions, methodCalls } = await composer.build()
	* ```
	*/
	async build() {
		if (this.atc.getStatus() === algosdk.default.AtomicTransactionComposerStatus.BUILDING) {
			const suggestedParams = await this.getSuggestedParams();
			const txnWithSigners = [];
			for (const txn of this.txns) txnWithSigners.push(...await this.buildTxnWithSigner(txn, suggestedParams));
			const methodCalls = /* @__PURE__ */ new Map();
			txnWithSigners.forEach(({ context, ...ts }, idx) => {
				this.atc.addTransaction(ts);
				if (context.abiMethod) methodCalls.set(idx, context.abiMethod);
				if (context.maxFee !== void 0) this.txnMaxFees.set(idx, context.maxFee);
			});
			this.atc["methodCalls"] = methodCalls;
		}
		const transactions = this.atc.buildGroup();
		return {
			atc: this.atc,
			transactions,
			methodCalls: this.atc["methodCalls"]
		};
	}
	/**
	* Rebuild the group, discarding any previously built transactions.
	* This will potentially cause new signers and suggested params to be used if the callbacks return a new value compared to the first build.
	* @returns The newly built atomic transaction composer and the transactions
	* @example
	* ```typescript
	* const { atc, transactions, methodCalls } = await composer.rebuild()
	* ```
	*/
	async rebuild() {
		this.atc = new algosdk.default.AtomicTransactionComposer();
		return await this.build();
	}
	/**
	* Compose the atomic transaction group and send it to the network.
	* @param params The parameters to control execution with
	* @returns The execution result
	* @example
	* ```typescript
	* const result = await composer.send()
	* ```
	*/
	async send(params) {
		const group = (await this.build()).transactions;
		let waitRounds = params?.maxRoundsToWaitForConfirmation;
		const suggestedParams = waitRounds === void 0 || params?.coverAppCallInnerTransactionFees ? await this.getSuggestedParams() : void 0;
		if (waitRounds === void 0) {
			const lastRound = group.reduce((max, txn) => txn.txn.lastValid > max ? txn.txn.lastValid : BigInt(max), 0n);
			const { firstValid: firstRound } = suggestedParams;
			waitRounds = Number(BigInt(lastRound) - BigInt(firstRound)) + 1;
		}
		try {
			return await require_transaction.sendAtomicTransactionComposer({
				atc: this.atc,
				suppressLog: params?.suppressLog,
				maxRoundsToWaitForConfirmation: waitRounds,
				populateAppCallResources: params?.populateAppCallResources,
				coverAppCallInnerTransactionFees: params?.coverAppCallInnerTransactionFees,
				additionalAtcContext: params?.coverAppCallInnerTransactionFees ? {
					maxFees: this.txnMaxFees,
					suggestedParams
				} : void 0
			}, this.algod);
		} catch (originalError) {
			throw await this.transformError(originalError);
		}
	}
	/**
	* @deprecated Use `send` instead.
	*
	* Compose the atomic transaction group and send it to the network
	*
	* An alias for `composer.send(params)`.
	* @param params The parameters to control execution with
	* @returns The execution result
	*/
	async execute(params) {
		return this.send(params);
	}
	async simulate(options) {
		const { skipSignatures = false, signal, ...rawOptions } = options ?? {};
		signal?.throwIfAborted();
		const validity = this.validityForSimulateRound(rawOptions.round);
		const atc = skipSignatures || validity ? new AtomicTransactionComposer() : this.atc;
		if (skipSignatures) {
			rawOptions.allowEmptySignatures = true;
			rawOptions.fixSigners = true;
			const transactions = await this.buildTransactionsIn(validity);
			for (const txn of transactions.transactions) atc.addTransaction({
				txn,
				signer: TransactionComposer.NULL_SIGNER
			});
			atc["methodCalls"] = transactions.methodCalls;
		} else if (validity) {
			const suggestedParams = await this.suggestedParamsFor(validity);
			const methodCalls = /* @__PURE__ */ new Map();
			for (const txn of this.txns) for (const { context, ...ts } of await this.buildTxnWithSigner(txn, suggestedParams)) {
				atc.addTransaction(ts);
				if (context.abiMethod) methodCalls.set(atc.count() - 1, context.abiMethod);
			}
			atc["methodCalls"] = methodCalls;
		} else await this.build();
		signal?.throwIfAborted();
		const { methodResults, simulateResponse } = await atc.simulate(this.algod, new modelsv2.SimulateRequest({
			txnGroups: [],
			...rawOptions,
			...require_config.Config.debug ? {
				allowEmptySignatures: true,
				fixSigners: true,
				allowMoreLogging: true,
				execTraceConfig: new modelsv2.SimulateTraceConfig({
					enable: true,
					scratchChange: true,
					stackChange: true,
					stateChange: true
				})
			} : void 0
		}));
		signal?.throwIfAborted();
		const failedGroup = simulateResponse?.txnGroups[0];
		if (failedGroup?.failureMessage) {
			const errorMessage = `Transaction failed at transaction(s) ${failedGroup.failedAt?.join(", ") || "unknown"} in the group. ${failedGroup.failureMessage}`;
			const error = new Error(errorMessage);
			if (require_config.Config.debug) await require_config.Config.events.emitAsync("TxnGroupSimulated", { simulateResponse });
			throw await this.transformError(error);
		}
		if (require_config.Config.debug && require_config.Config.traceAll) await require_config.Config.events.emitAsync("TxnGroupSimulated", { simulateResponse });
		const transactions = require_resolve_signed_transactions.resolveSignedTransactions(atc.buildGroup().map((t) => t.txn), await atc.gatherSignatures());
		const methodCalls = [...atc["methodCalls"].values()];
		return {
			confirmations: simulateResponse.txnGroups[0].txnResults.map((t) => t.txnResult),
			transactions,
			txIds: transactions.map((t) => t.txID()),
			groupId: Buffer.from(transactions[0].group ?? /* @__PURE__ */ new Uint8Array()).toString("base64"),
			simulateResponse,
			returns: methodResults.map((r, i) => require_transaction.getABIReturnValue(r, methodCalls[i].returns.type))
		};
	}
	/**
	* Create an encoded transaction note that follows the ARC-2 spec.
	*
	* https://github.com/algorandfoundation/ARCs/blob/main/ARCs/arc-0002.md
	* @param note The ARC-2 transaction note data
	* @returns The binary encoded transaction note
	*/
	static arc2Note(note) {
		const arc2Payload = `${note.dAppName}:${note.format}${typeof note.data === "string" ? note.data : require_util.asJson(note.data)}`;
		return new TextEncoder().encode(arc2Payload);
	}
};
/**
* Returns an `algosdk.TransactionResourceReference` given a `ResourceReference`.
*/
function getResourceReference(accessReference) {
	return {
		address: typeof accessReference.address === "string" ? algosdk.Address.fromString(accessReference.address) : accessReference.address,
		appIndex: accessReference.appId,
		assetIndex: accessReference.assetId,
		holding: accessReference.holding ? getHoldingReference(accessReference.holding) : void 0,
		locals: accessReference.locals ? getLocalsReference(accessReference.locals) : void 0,
		box: accessReference.box ? require_app_manager.AppManager.getBoxReference(accessReference.box) : void 0
	};
}
function getHoldingReference(holdingReference) {
	return {
		assetIndex: holdingReference.assetId,
		address: typeof holdingReference.address === "string" ? algosdk.Address.fromString(holdingReference.address) : holdingReference.address
	};
}
function getLocalsReference(localsReference) {
	return {
		appIndex: localsReference.appId,
		address: typeof localsReference.address === "string" ? algosdk.Address.fromString(localsReference.address) : localsReference.address
	};
}
//#endregion
exports.MAX_TRANSACTION_GROUP_SIZE = MAX_TRANSACTION_GROUP_SIZE;
exports.TransactionComposer = TransactionComposer;

//# sourceMappingURL=composer.js.map