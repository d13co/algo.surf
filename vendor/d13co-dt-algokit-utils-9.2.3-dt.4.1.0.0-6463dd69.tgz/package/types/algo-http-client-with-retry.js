Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
const require_config = require("../config.js");
let algosdk = require("algosdk");
let algosdk_client = require("algosdk/client");
//#region src/types/algo-http-client-with-retry.ts
/**
* A HTTP Client that wraps the Algorand SDK HTTP Client with retries.
*
* A 429 or 503 with a `Retry-After` header waits at least that long before the next try (capped at 10 s). A dtalgod 503
* for a busy node ("node is busy", or no slot free to re-evaluate an old round's deltas) without a readable header (a
* proxy may drop it) waits at least 1 s. A 503 for history
* the node can't serve (an incomplete box or holders index, an untrusted history) is not retried: it lasts until the node
* is fixed. A 504 (the node's time limit) is not retried from `POST /v2/query` or from `GET` of `/versions` and `/holders`
* listings: a retry repeats the whole work, and the caller narrows the request instead.
*/
var AlgoHttpClientWithRetry = class AlgoHttpClientWithRetry extends algosdk_client.URLTokenBaseHTTPClient {
	static MAX_TRIES = 5;
	static MAX_BACKOFF_MS = 1e4;
	static RETRY_STATUS_CODES = [
		408,
		413,
		429,
		500,
		502,
		503,
		504
	];
	/**
	* The status codes retried for requests with a time limit on the node (`POST /v2/query`,
	* `POST /v2/transactions/simulate`, `GET /v2/deltas/{round}`, and `GET` of `/versions` and `/holders` listings): all
	* but 504, which is that limit. A retry would repeat the whole (up to the limit) work; the caller splits or narrows the
	* request instead.
	*/
	static TIME_LIMITED_RETRY_STATUS_CODES = AlgoHttpClientWithRetry.RETRY_STATUS_CODES.filter((s) => s !== 504);
	/**
	* dtalgod's 503s when it has no capacity left for a request (simulate, query, versions), or no slot to re-evaluate an
	* old round's deltas: worth a retry, but not at once.
	*/
	static BUSY = /node is busy|every slot for re-evaluating old rounds is in use/;
	/** The least wait before retrying a busy node that gave no readable `Retry-After`. */
	static BUSY_MIN_BACKOFF_MS = 1e3;
	/**
	* dtalgod's 503s for history it can't serve until an operator fixes the node: an incomplete box or holders index, or
	* a time-travel history marked as differing from the chain. Retrying them only delays the error.
	*/
	static HISTORY_UNAVAILABLE = /box index is incomplete|holders index is not complete|history is not served/;
	/** The status codes whose `Retry-After` header is honored. */
	static RETRY_AFTER_STATUS_CODES = [429, 503];
	static RETRY_ERROR_CODES = [
		"ETIMEDOUT",
		"ECONNRESET",
		"EADDRINUSE",
		"ECONNREFUSED",
		"EPIPE",
		"ENOTFOUND",
		"ENETUNREACH",
		"EAI_AGAIN",
		"EPROTO"
	];
	/** The abort signal in fetch options passed as `customOptions`, if any. */
	static signalOf(customOptions) {
		const signal = customOptions?.signal;
		return signal && typeof signal === "object" && "aborted" in signal ? signal : void 0;
	}
	/** Waits `ms`, rejecting with the signal's reason as soon as it aborts. */
	static sleep(ms, signal) {
		return new Promise((resolve, reject) => {
			if (signal?.aborted) return reject(signal.reason);
			const onAbort = () => {
				clearTimeout(timer);
				reject(signal.reason);
			};
			const timer = setTimeout(() => {
				signal?.removeEventListener("abort", onAbort);
				resolve();
			}, ms);
			signal?.addEventListener("abort", onAbort, { once: true });
		});
	}
	/**
	* How long a failed response asks to wait before retrying, from its `Retry-After` header (seconds or an HTTP date),
	* or undefined without one. Only for 429 and 503. The header name is looked up case-insensitively.
	*/
	static retryAfterMs(err) {
		const status = Number(err?.response?.status ?? err?.status);
		if (!AlgoHttpClientWithRetry.RETRY_AFTER_STATUS_CODES.includes(status)) return void 0;
		const headers = err?.response?.headers;
		if (!headers || typeof headers !== "object") return void 0;
		const key = Object.keys(headers).find((k) => k.toLowerCase() === "retry-after");
		if (key === void 0) return void 0;
		const value = String(headers[key]).trim();
		if (/^\d+$/.test(value)) return Number(value) * 1e3;
		const date = Date.parse(value);
		return Number.isNaN(date) ? void 0 : Math.max(0, date - Date.now());
	}
	/** The HTTP status of a failed request, or NaN. */
	static statusOf(err) {
		return Number(err?.response?.status ?? err?.status);
	}
	/** The error's message, and the `message` of its JSON body if it has one (algosdk puts it in the message, other clients may not). */
	static messageOf(err) {
		const message = typeof err?.message === "string" ? err.message : "";
		const body = err?.response?.body;
		if (!(body instanceof Uint8Array) || body.length === 0) return message;
		try {
			const bodyMessage = JSON.parse(new TextDecoder().decode(body))?.message;
			return typeof bodyMessage === "string" ? `${message}\n${bodyMessage}` : message;
		} catch {
			return message;
		}
	}
	/** The status codes to retry for a `method` request to `relativePath`. */
	static retryStatusCodes(method, relativePath) {
		const path = relativePath.replace(/\/+$/, "");
		return (method === "post" ? path === "/v2/query" || path === "/v2/transactions/simulate" : /\/(versions|holders)$|^\/v2\/deltas\/\d+$/.test(path)) ? AlgoHttpClientWithRetry.TIME_LIMITED_RETRY_STATUS_CODES : AlgoHttpClientWithRetry.RETRY_STATUS_CODES;
	}
	async callWithRetry(func, signal, retryStatusCodes = AlgoHttpClientWithRetry.RETRY_STATUS_CODES) {
		let response;
		let numTries = 1;
		do {
			signal?.throwIfAborted();
			try {
				response = await func();
			} catch (err) {
				if (signal?.aborted) throw err;
				if (numTries >= AlgoHttpClientWithRetry.MAX_TRIES) throw err;
				if (!(AlgoHttpClientWithRetry.RETRY_ERROR_CODES.includes(err.code) || retryStatusCodes.includes(Number(err.status)) || "response" in err && retryStatusCodes.includes(Number(err.response.status)))) throw err;
				const unavailable = AlgoHttpClientWithRetry.statusOf(err) === 503;
				const message = unavailable ? AlgoHttpClientWithRetry.messageOf(err) : "";
				if (unavailable && AlgoHttpClientWithRetry.HISTORY_UNAVAILABLE.test(message)) throw err;
				const retryAfterMs = AlgoHttpClientWithRetry.retryAfterMs(err);
				const busy = unavailable && retryAfterMs === void 0 && AlgoHttpClientWithRetry.BUSY.test(message);
				const backoffMs = Math.max(numTries == 1 ? 0 : Math.min(1e3 * Math.pow(2, numTries - 1), AlgoHttpClientWithRetry.MAX_BACKOFF_MS), busy ? AlgoHttpClientWithRetry.BUSY_MIN_BACKOFF_MS : 0);
				const delayTimeMs = retryAfterMs === void 0 ? backoffMs : Math.min(Math.max(backoffMs, retryAfterMs), AlgoHttpClientWithRetry.MAX_BACKOFF_MS);
				if (delayTimeMs > 0) await AlgoHttpClientWithRetry.sleep(delayTimeMs, signal);
				require_config.Config.logger.warn(`algosdk request failed ${numTries} times. Retrying in ${delayTimeMs}ms: ${err}`);
			}
		} while (!response && ++numTries <= AlgoHttpClientWithRetry.MAX_TRIES);
		return response;
	}
	async get(relativePath, query, requestHeaders = {}, customOptions) {
		const response = await this.callWithRetry(() => super.get(relativePath, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions), AlgoHttpClientWithRetry.retryStatusCodes("get", relativePath));
		if (relativePath.startsWith("/v2/accounts/") && relativePath.endsWith("/created-applications") && response.status === 200 && query?.["include-all"]?.toString() === "true") try {
			const json = (0, algosdk.parseJSON)(Buffer.from(response.body).toString(), { intDecoding: algosdk.IntDecoding.MIXED });
			if (json.applications) {
				for (const app of json.applications) if (app.params) {
					if (app.params["approval-program"] === null) app.params["approval-program"] = "";
					if (app.params["clear-state-program"] === null) app.params["clear-state-program"] = "";
				}
				response.body = Buffer.from((0, algosdk.stringifyJSON)(json));
			}
		} catch (e) {
			require_config.Config.logger.warn("Failed to fix indexer response for created applications", e);
		}
		return response;
	}
	async post(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry(() => super.post(relativePath, data, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions), AlgoHttpClientWithRetry.retryStatusCodes("post", relativePath));
	}
	async delete(relativePath, data, query, requestHeaders = {}, customOptions) {
		return await this.callWithRetry(() => super.delete(relativePath, data, query, requestHeaders, customOptions), AlgoHttpClientWithRetry.signalOf(customOptions));
	}
};
//#endregion
exports.AlgoHttpClientWithRetry = AlgoHttpClientWithRetry;

//# sourceMappingURL=algo-http-client-with-retry.js.map