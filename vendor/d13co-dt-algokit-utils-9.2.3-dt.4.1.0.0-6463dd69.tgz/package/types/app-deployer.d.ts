import algosdk, { Address } from 'algosdk';
import { AlgorandClientTransactionSender } from './algorand-client-transaction-sender';
import { OnSchemaBreak, OnUpdate, type ABIReturn, type AppDeployMetadata, type SendAppCreateTransactionResult, type SendAppUpdateTransactionResult, type TealTemplateParams } from './app';
import { AppManager } from './app-manager';
import { AppCreateMethodCall, AppCreateParams, AppDeleteMethodCall, AppDeleteParams, AppUpdateMethodCall, AppUpdateParams } from './composer';
import { Expand } from './expand';
import { ConfirmedTransactionResult, SendParams } from './transaction';
/** Params to specify an update transaction for an app deployment */
export type DeployAppUpdateParams = Expand<Omit<AppUpdateParams, 'appId' | 'approvalProgram' | 'clearStateProgram'>>;
/** Params to specify an update method call for an app deployment */
export type DeployAppUpdateMethodCall = Expand<Omit<AppUpdateMethodCall, 'appId' | 'approvalProgram' | 'clearStateProgram'>>;
/** Params to specify a transaction for an app deployment */
export type DeployAppDeleteParams = Expand<Omit<AppDeleteParams, 'appId'>>;
/** Params to specify a delete method call for an app deployment */
export type DeployAppDeleteMethodCall = Expand<Omit<AppDeleteMethodCall, 'appId'>>;
/** The parameters to idempotently deploy an app */
export type AppDeployParams = Expand<SendParams & {
    /** The deployment metadata */
    metadata: AppDeployMetadata;
    /** Any deploy-time parameters to replace in the TEAL code before compiling it (used if teal code is passed in as a string) */
    deployTimeParams?: TealTemplateParams;
    /** What action to perform if a schema break (storage schema or extra pages change) is detected:
     *
     * * `fail` - Fail the deployment (throw an error, **default**)
     * * `replace` - Delete the old app and create a new one
     * * `append` - Deploy a new app and leave the old one as is
     */
    onSchemaBreak?: 'replace' | 'fail' | 'append' | OnSchemaBreak;
    /** What action to perform if a TEAL code update is detected:
     *
     * * `fail` - Fail the deployment (throw an error, **default**)
     * * `update` - Update the app with the new TEAL code
     * * `replace` - Delete the old app and create a new one
     * * `append` - Deploy a new app and leave the old one as is
     */
    onUpdate?: 'update' | 'replace' | 'fail' | 'append' | OnUpdate;
    /** Create transaction parameters to use if a create needs to be issued as part of deployment */
    createParams: AppCreateParams | AppCreateMethodCall;
    /** Update transaction parameters to use if an update needs to be issued as part of deployment */
    updateParams: DeployAppUpdateParams | DeployAppUpdateMethodCall;
    /** Delete transaction parameters to use if a delete needs to be issued as part of deployment */
    deleteParams: DeployAppDeleteParams | DeployAppDeleteMethodCall;
    /** Optional cached value of the existing apps for the given creator; use this to avoid an indexer lookup */
    existingDeployments?: AppLookup;
    /** Whether or not to ignore the app metadata cache and force a lookup, default: use the cache **/
    ignoreCache?: boolean;
}>;
/** The metadata that can be collected about a deployed app */
export interface AppMetadata extends AppDeployMetadata {
    /** The id of the app */
    appId: bigint;
    /** The Algorand address of the account associated with the app */
    appAddress: Address;
    /** The round the app was created */
    createdRound: bigint;
    /** The last round that the app was updated */
    updatedRound: bigint;
    /** The metadata when the app was created */
    createdMetadata: AppDeployMetadata;
    /** Whether or not the app is deleted */
    deleted: boolean;
}
/** A lookup of name -> Algorand app for a creator */
export interface AppLookup {
    /** The address of the creator associated with this lookup */
    creator: Readonly<Address>;
    /** A hash map of app name to app metadata */
    apps: {
        [name: string]: AppMetadata;
    };
}
export type AppDeployResult = Expand<{
    operationPerformed: 'create';
} & Omit<AppMetadata, 'appId' | 'appAddress'> & SendAppCreateTransactionResult> | Expand<{
    operationPerformed: 'update';
} & AppMetadata & SendAppUpdateTransactionResult> | Expand<{
    operationPerformed: 'replace';
} & Omit<AppMetadata, 'appId' | 'appAddress'> & SendAppCreateTransactionResult & {
    deleteReturn?: ABIReturn;
    deleteResult: ConfirmedTransactionResult;
}> | Expand<{
    operationPerformed: 'nothing';
} & AppMetadata>;
/** Allows management of deployment and deployment metadata of applications. */
export declare class AppDeployer {
    private _appManager;
    private _transactionSender;
    private _indexer?;
    private _appLookups;
    /**
     * Creates an `AppManager`
     * @param appManager An `AppManager` instance
     * @param transactionSender An `AlgorandClientTransactionSender` instance
     * @param indexer An optional indexer instance; supply if you want to indexer to look up app metadata
     * @example
     * ```ts
     * const deployer = new AppDeployer(appManager, transactionSender, indexer)
     * ```
     */
    constructor(appManager: AppManager, transactionSender: AlgorandClientTransactionSender, indexer?: algosdk.Indexer);
    /**
     * Idempotently deploy (create if not exists, update if changed) an app against the given name for the given creator account, including deploy-time TEAL template placeholder substitutions (if specified).
     *
     * To understand the architecture decisions behind this functionality please see https://github.com/algorandfoundation/algokit-cli/blob/main/docs/src/content/docs/architecture-decisions/2023-01-12_smart-contract-deployment.md
     *
     * **Note:** When using the return from this function be sure to check `operationPerformed` to get access to various return properties like `transaction`, `confirmation` and `deleteResult`.
     *
     * **Note:** if there is a breaking state schema change to an existing app (and `onSchemaBreak` is set to `'replace'`) the existing app will be deleted and re-created.
     *
     * **Note:** if there is an update (different TEAL code) to an existing app (and `onUpdate` is set to `'replace'`) the existing app will be deleted and re-created.
     * @param deployment The arguments to control the app deployment
     * @returns The result of the deployment
     * @example
     * ```ts
     * const deployResult = await deployer.deploy({
     *   createParams: {
     *     sender: 'SENDER_ADDRESS',
     *     approvalProgram: 'APPROVAL PROGRAM',
     *     clearStateProgram: 'CLEAR PROGRAM',
     *     schema: {
     *       globalByteSlices: 0,
     *       globalInts: 0,
     *       localByteSlices: 0,
     *       localInts: 0
     *     }
     *   },
     *   updateParams: {
     *     sender: 'SENDER_ADDRESS'
     *   },
     *   deleteParams: {
     *     sender: 'SENDER_ADDRESS'
     *   },
     *   metadata: { name: 'my_app', version: '2.0', updatable: false, deletable: false },
     *   onSchemaBreak: 'append',
     *   onUpdate: 'append'
     *  })
     * ```
     */
    deploy(deployment: AppDeployParams): Promise<AppDeployResult>;
    private updateAppLookup;
    /**
     * Returns a lookup of name => app metadata (id, address, ...metadata) for all apps created by the given account that have
     * an [ARC-2](https://github.com/algorandfoundation/ARCs/blob/main/ARCs/arc-0002.md) `AppDeployNote` as the transaction
     * note of the app creation transaction.
     *
     * This function caches the result for the given creator account so that subsequent calls will not require an indexer lookup.
     *
     * If the `AppManager` instance wasn't created with an indexer client, this function will throw an error.
     *
     * @param creatorAddress The address of the account that is the creator of the apps you want to search for
     * @param ignoreCache Whether or not to ignore the cache and force a lookup, default: use the cache
     * @returns A name-based lookup of the app metadata
     * @example
     * ```ts
     * const result = await deployer.getCreatorAppsByName(creator)
     */
    getCreatorAppsByName(creatorAddress: string | Address, ignoreCache?: boolean): Promise<AppLookup>;
}
