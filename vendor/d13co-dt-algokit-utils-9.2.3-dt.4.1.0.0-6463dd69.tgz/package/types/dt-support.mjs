import algosdk from "algosdk";
import { Buffer } from "buffer";
//#region src/types/dt-support.ts
/**
* Runtime support for dtalgod (a time-travel algod) through the time-travel fork of algosdk.
*
* algokit-utils keeps working with stock algosdk: the fork's `DTAlgodClient` is looked up at runtime, and
* the features that need it throw a {@link DTNotAvailableError} when it isn't there. The types below describe
* the parts of the fork that algokit-utils uses, in terms of stock algosdk types, so that the published declarations
* never reference the fork.
*/
/**
* The `DTAlgodClient.features` that algokit-utils uses. They tell dt-algosdk from stock algosdk: they describe the SDK
* build, not the node.
*/
const REQUIRED_DT_FEATURES = Object.freeze([
	"reads-at-round",
	"versions",
	"simulate-groups",
	"parallel-groups",
	"simulate-rounds",
	"from",
	"group-results",
	"from-transactions",
	"pack-rounds",
	"validity-window",
	"simulate-protocol",
	"capabilities",
	"query",
	"versions-rounds",
	"versions-keys",
	"versions-pages",
	"holders",
	"round-header"
]);
/** Thrown when a time travel, extended simulate or query feature is used but the loaded algosdk is not dt-algosdk (the time-travel fork). */
var DTNotAvailableError = class extends Error {
	/** @param feature The feature that was used, for the message */
	constructor(feature) {
		super(`${feature} needs dt-algosdk, the time-travel fork of algosdk (with DTAlgodClient features ${REQUIRED_DT_FEATURES.join(", ")}), but the loaded algosdk is not it. Install dt-algosdk in place of algosdk and make sure the app loads a single copy of algosdk.`);
		this.name = "DTNotAvailableError";
	}
};
/** The fetch options (`customOptions`) that carry an abort signal to algosdk's `.do()`, if there is one. */
const fetchOptions = (options) => options?.signal ? { signal: options.signal } : void 0;
/** The order the node lists protocol notes in; codes it adds later go after these. */
const PROTOCOL_NOTE_ORDER = [
	"semantics-changed",
	"no-heartbeat-challenges",
	"no-load-history",
	"block-incentive-fields",
	"block-hash-fields",
	"online-stake-includes-expired",
	"account-incentive-fields",
	"app-version-starts-at-upgrade"
];
/**
* A protocol override with each note hit replaced by `map(hit)`: for results of requests that hold only part of the
* groups or calls asked for. Notes without hits, and an override without notes, are kept as they are.
* @param override The override of one request at one round, if any
* @param map The new hit for a hit of that request
*/
function mapProtocolOverrideHits(override, map) {
	if (!override || !override.notes) return override;
	return {
		...override,
		notes: override.notes.map((n) => n.hits ? {
			...n,
			hits: n.hits.map(map)
		} : n)
	};
}
/**
* A protocol override with the notes' group indexes moved by `offset`: for a request whose first group (or call) is the
* `offset`th of those asked for.
*/
function offsetProtocolOverride(override, offset) {
	if (offset === 0) return override;
	return mapProtocolOverrideHits(override, (h) => ({
		...h,
		group: h.group + offset
	}));
}
/**
* Merges the protocol overrides of the requests that the groups (or calls) of one round were split across: notes with the
* same code and message become one with all their hits, in the node's note order, and the override is `applied` if it
* applied in any request. Undefined when no request has one.
*/
function mergeProtocolOverrides(overrides) {
	const present = overrides.filter((o) => o !== void 0);
	if (present.length <= 1) return present[0];
	const notes = [];
	for (const n of present.flatMap((o) => o.notes ?? [])) {
		const same = notes.find((m) => m.code === n.code && m.message === n.message);
		if (!same) notes.push({
			...n,
			...n.hits ? { hits: [...n.hits] } : {}
		});
		else if (n.hits) same.hits = [...same.hits ?? [], ...n.hits];
	}
	const rank = (code) => PROTOCOL_NOTE_ORDER.includes(code) ? PROTOCOL_NOTE_ORDER.indexOf(code) : PROTOCOL_NOTE_ORDER.length;
	notes.sort((a, b) => rank(a.code) - rank(b.code));
	return {
		from: present[0].from,
		to: present[0].to,
		applied: present.some((o) => o.applied),
		...notes.length ? { notes } : {}
	};
}
/**
* Returns a built group as simulate and queries send it: a group of several transactions as copies with a group ID for
* the whole group, replacing any they had. Copies, because the composer reuses the transactions passed to it already
* built (method call arguments, `addTransaction`) across its builds, and a group ID left on them breaks its later builds.
*/
function asSentGroup(built) {
	if (built.transactions.length < 2) return built;
	const transactions = built.transactions.map((t) => {
		const copy = algosdk.decodeUnsignedTransaction(algosdk.encodeUnsignedTransaction(t));
		copy.group = void 0;
		return copy;
	});
	algosdk.assignGroupID(transactions);
	return {
		...built,
		transactions
	};
}
/** The IDs of built groups' transactions, by the built group, with the group ID they were hashed under. */
const builtTxIds = /* @__PURE__ */ new WeakMap();
/**
* The base64 group ID and the transaction IDs of a built group, hashed once per group ID. Requests with `rounds` return
* the same group at every round, and hashing its transactions again for each was a large part of the time spent on the
* response. The `txIds` array is shared: copy it before handing it out.
*/
function txIdsOf(built) {
	const groupId = Buffer.from(built.transactions[0].group ?? /* @__PURE__ */ new Uint8Array()).toString("base64");
	const cached = builtTxIds.get(built);
	if (cached && cached.groupId === groupId) return cached;
	const ids = {
		groupId,
		txIds: built.transactions.map((t) => t.txID())
	};
	builtTxIds.set(built, ids);
	return ids;
}
/**
* Returns a function that runs tasks at most `concurrency` at a time, in the order they are given. After a task fails,
* the tasks not yet started reject with that error instead of running.
*/
function concurrencyLimiter(concurrency) {
	let active = 0;
	let failure;
	const waiting = [];
	return async (task) => {
		if (active >= concurrency) await new Promise((resolve) => waiting.push(resolve));
		else active++;
		try {
			if (failure) throw failure.error;
			return await task();
		} catch (error) {
			failure ??= { error };
			throw error;
		} finally {
			const next = waiting.shift();
			if (next) next();
			else active--;
		}
	};
}
/**
* Maps `items` with `fn`, at most `concurrency` at a time, keeping the order. The first failure rejects the result; the
* calls already started run on, and no new one starts after it.
*/
async function mapConcurrently(items, concurrency, fn) {
	const results = new Array(items.length);
	let nextIndex = 0;
	let failed = false;
	const worker = async () => {
		while (!failed && nextIndex < items.length) {
			const index = nextIndex++;
			try {
				results[index] = await fn(items[index], index);
			} catch (error) {
				failed = true;
				throw error;
			}
		}
	};
	await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
	return results;
}
/** Splits `items` into consecutive chunks of at most `size`. */
const chunk = (items, size) => {
	const chunks = [];
	for (let i = 0; i < items.length; i += size) chunks.push(items.slice(i, i + size));
	return chunks;
};
const sdk = algosdk;
/** Returns the parts of dt-algosdk (the time-travel fork of algosdk) that algokit-utils uses, or `undefined` with stock algosdk. */
function getDTSdk() {
	const features = sdk.DTAlgodClient?.features;
	if (!features || !REQUIRED_DT_FEATURES.every((f) => features.includes(f))) return void 0;
	return sdk;
}
/** Returns the parts of dt-algosdk that algokit-utils uses, or throws a {@link DTNotAvailableError}. */
function requireDTSdk(feature) {
	const tt = getDTSdk();
	if (!tt) throw new DTNotAvailableError(feature);
	return tt;
}
/**
* Returns a time-travel algod client that shares the connection (server, token, headers and HTTP client) of the given
* algod client. The same client is returned for the same `algod`, so what it caches (the node's capabilities) is kept.
*
* @param algod The algod client to share the connection of
* @param feature The feature that needs the client, for the error message
* @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
*/
function toDTAlgod(algod, feature = "This feature") {
	return requireDTSdk(feature).DTAlgodClient.from(algod);
}
/**
* Returns the node's capabilities, through dt-algosdk's cached `DTAlgodClient.capabilities()`: stock algod's values
* (`reported` false) on stock algod. Returns `undefined` when the loaded algosdk is not dt-algosdk, so they are unknown.
* @param algod The algod client to ask
* @throws The request's error, other than a 404
*/
async function getCapabilities(algod) {
	const tt = getDTSdk();
	if (!tt) return void 0;
	const { reported, timeTravel, developerApi, timeLimitSeconds, simulate, query } = await tt.DTAlgodClient.from(algod).capabilities();
	return {
		reported,
		timeTravel,
		developerApi,
		timeLimitSeconds,
		simulate: {
			maxTxnGroups: simulate.maxTxnGroups,
			maxRounds: simulate.maxRounds,
			maxExtraOpcodeBudget: simulate.maxExtraOpcodeBudget,
			resourceLimitMultiplier: simulate.resourceLimitMultiplier
		},
		...query ? { query: {
			maxCalls: query.maxCalls,
			maxCallBudget: query.maxCallBudget,
			maxCallLogBytes: query.maxCallLogBytes,
			maxResponseBytes: query.maxResponseBytes,
			maxRounds: query.maxRounds,
			maxTotalCalls: query.maxTotalCalls || query.maxCalls * Math.max(1, query.maxRounds)
		} } : {}
	};
}
/**
* Returns the node's query limits (`query` of its capabilities), or `undefined` when the node has no queries (stock
* algod, or dtalgod with queries disabled) or the loaded algosdk is not dt-algosdk.
* @param algod The algod client to ask
* @throws The capabilities request's error, other than a 404
*/
async function getQueryLimits(algod) {
	return (await getCapabilities(algod))?.query;
}
/** The message of the error for a node without queries, from its capabilities. */
const noQueryMessage = (capabilities) => capabilities?.reported ? "The node has queries disabled (MaxAPIQueryCalls is 0)" : "Querying needs dtalgod, but the node is stock algod (it has no POST /v2/query)";
/**
* Returns whether an error is dt-algosdk's `DTUnsupportedError`: the node lacks a feature the request needs (it is stock
* algod, or dtalgod with the feature off), or can't serve the round asked for.
*/
function isDTUnsupportedError(error) {
	const ctor = sdk.DTUnsupportedError;
	return ctor !== void 0 && error instanceof ctor || error instanceof Error && error.name === "DTUnsupportedError";
}
/**
* Returns the node's capabilities after checking that the node is dtalgod: the one check that tells dtalgod from stock
* algod, read once per algod client.
*
* @param algod The algod client to ask
* @param feature The feature that needs dtalgod, for the error message
* @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
* @throws DTUnsupportedError if the node is stock algod
*/
async function requireDTNode(algod, feature) {
	const tt = requireDTSdk(feature);
	const capabilities = await getCapabilities(algod);
	if (!capabilities.reported) throw new tt.DTUnsupportedError(`${feature} needs dtalgod, but the node is stock algod`);
	return capabilities;
}
/**
* Returns a time-travel algod client after checking that the node has time travel (`supportsDT()`, read once per algod
* client from its capabilities). Every read at a round, `/versions` listing and holders listing goes through this
* check, since stock algod ignores `round` and answers with the latest state.
*
* @param algod The algod client to share the connection of
* @param feature The feature that needs time travel, for the error message
* @param round The round asked for, if any
* @throws DTNotAvailableError if the loaded algosdk is not dt-algosdk
* @throws DTUnsupportedError if the node is stock algod, or dtalgod with time travel off
*/
async function requireTimeTravel(algod, feature, round) {
	const tt = requireDTSdk(feature);
	const client = tt.DTAlgodClient.from(algod);
	if (!await client.supportsDT()) {
		const { reported } = await client.capabilities();
		const at = round === void 0 ? "" : ` at round ${round}`;
		throw new tt.DTUnsupportedError(`${feature}${at} needs dtalgod with time travel, but ${reported ? "the node has time travel off (EnableTimeTravel)" : "the node is stock algod"}`, round === void 0 ? {} : { requestedRound: BigInt(round) });
	}
	return client;
}
//#endregion
export { DTNotAvailableError, PROTOCOL_NOTE_ORDER, REQUIRED_DT_FEATURES, asSentGroup, chunk, concurrencyLimiter, fetchOptions, getCapabilities, getDTSdk, getQueryLimits, isDTUnsupportedError, mapConcurrently, mapProtocolOverrideHits, mergeProtocolOverrides, noQueryMessage, offsetProtocolOverride, requireDTNode, requireDTSdk, requireTimeTravel, toDTAlgod, txIdsOf };

//# sourceMappingURL=dt-support.mjs.map